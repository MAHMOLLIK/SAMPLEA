package main.java;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class ReadCucumberJSON {

	static List<HashMap<String, String>> allResult = new ArrayList<>();
	static List<HashMap<String, String>> summary = new ArrayList<>();
	static int totalTestCase = 0;
	static int totalPass = 0;
	static int totalFail = 0;
	static String totalPassPercentage;
	static String totalFailPercentage;

	public static void main(String[] args) throws IOException {


		for (int i = 0; i < allJsonFiles.size(); i++) {
			getScenarioDetailsFromJSONFile(allJsonFiles.get(i));
		}
		getSummary(allResult);
		createHtmlReport(allResult, "");
	}

	/**
	 * This method will scan the JSON file and put all the scenario details into
	 * a HashMap<String,String> format and return.
	 * 
	 * @param stepArray
	 * @param scenarioName
	 * @param featureName
	 * @return HashMap<String, String>
	 * @author Rakesh Ghosal
	 */
	public static HashMap<String, String> getScenarioStatus(JSONArray stepArray, String scenarioName,
			String featureName) {
		HashMap<String, String> scenarioResult = new HashMap<>();
		try {

			for (int i = 0; i < stepArray.size(); i++) {
				Object step = stepArray.get(i);
				JSONObject stepObject = (JSONObject) step;
				Object status = stepObject.get("result");
				JSONObject statusObject = (JSONObject) status;
				if (statusObject.get("status").toString().equalsIgnoreCase("failed")) {
					scenarioResult.put("Feature_Name", featureName);
					scenarioResult.put("Scenario_Name", scenarioName);
					scenarioResult.put("Status", "FAIL");
					String errorMessage = statusObject.get("error_message").toString();
					//int startIndex = errorMessage.indexOf(":") + 1;
					//int endIndex = errorMessage.indexOf("at org.junit.Assert");
					//scenarioResult.put("Error", errorMessage.substring(startIndex, endIndex).trim());
					//scenarioResult.put("Error", errorMessage.trim());
					return scenarioResult;
				}

			}

			scenarioResult.put("Feature_Name", featureName);
			scenarioResult.put("Scenario_Name", scenarioName);
			scenarioResult.put("Status", "PASS");
			scenarioResult.put("Error", " ");
			return scenarioResult;

		} catch (Exception e) {
			return scenarioResult;
		}
	}

	/**
	 * This method will scan the JSON file and get all the element object from
	 * it
	 * 
	 * @param jsonFileName
	 * @author Rakesh Ghosal
	 */
	public static void getScenarioDetailsFromJSONFile(String jsonFileName) {
		JSONParser jsonParser = new JSONParser();
		try (FileReader reader = new FileReader(System.getProperty("user.dir")+"//target//cucumber-parallel//" + jsonFileName)) {
			Object object = jsonParser.parse(reader);
			JSONArray node = (JSONArray) object;
			Object allObject = node.get(0);
			JSONObject jsonObject = (JSONObject) allObject;
			Object elementObject = jsonObject.get("elements");
			JSONArray elementArray = (JSONArray) elementObject;
			for (int i = 0; i < elementArray.size(); i++) {
				Object scenario1 = elementArray.get(i);
				JSONObject scenarioObject = (JSONObject) scenario1;
				Object stepObject = scenarioObject.get("steps");
				JSONArray stepArray = (JSONArray) stepObject;
				allResult.add(getScenarioStatus(stepArray, scenarioObject.get("name").toString(),
						jsonObject.get("name").toString().trim()));

			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	/**
	 * This method will get all the not corrupted JSON files from the directory
	 * mentioned and put it into a List<String>
	 * 
	 * @return List<String>
	 * @author Rakesh Ghosal
	 */
	public static List<String> getJsonFiles() {
		List<String> allJsonFiles = new ArrayList<String>();

		// Change the directory you want
		File folder = new File(System.getProperty("user.dir")+"//target//cucumber-parallel//");
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				if (listOfFiles[i].getName().endsWith("json")) {
					boolean jsonFileValidationStatus = validateEmptyJsonFile(
							System.getProperty("user.dir")+"//target//cucumber-parallel//" + listOfFiles[i].getName());
					System.out.println("File " + listOfFiles[i].getName() + jsonFileValidationStatus);
					if (jsonFileValidationStatus == true) {
						allJsonFiles.add(listOfFiles[i].getName());
					}
				}
			}
		}
		return allJsonFiles;
	}

	/**
	 * This method will validate if a generated JSON file is empty or not.
	 * 
	 * @param filePath
	 * @return boolean
	 * @author Rakesh Ghosal
	 */
	public static boolean validateEmptyJsonFile(String filePath) {
		try {
			File file = new File(filePath);

			if (file.length() == 0) {
				// Adding code to delete corrupted file so that Jenkins would
				// able to make report - Rakesh
				try {
					if (file.delete()) {
						System.out.println("Corrupted File Deleted Successfully ");
					}
				} catch (Exception e) {
					System.out.println("Corrupted file could not deleted successfully, exception occurred " + e);
				}
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			System.out.println("Exception occurred while validating JSON file is empty or not " + e);
			return false;
		}

	}

	/**
	 * This method will validate if a generated JSON file is empty or not.
	 * 
	 * @param filePath
	 * @return
	 * @author Rakesh Ghosal
	 */
	public static void getSummary(List<HashMap<String, String>> allResult) {
		try {

			DecimalFormat decimalFormat = new DecimalFormat("0.00");

			Set<String> uniqueFeatureFile = new HashSet<String>();
			for (int i = 0; i < allResult.size(); i++) {
				uniqueFeatureFile.add(allResult.get(i).get("Feature_Name"));
			}

			for (Iterator<String> it = uniqueFeatureFile.iterator(); it.hasNext();) {
				int passCount = 0;
				int failCount = 0;
				int total = 0;
				String passPercentage = "";
				String failPercentage = "";
				String featureFileName = it.next();
				HashMap<String, String> featureWiseSummary = new HashMap<>();
				for (int j = 0; j < allResult.size(); j++) {
					if (allResult.get(j).get("Feature_Name").equalsIgnoreCase(featureFileName)) {
						if (allResult.get(j).get("Status").equalsIgnoreCase("PASS")) {
							passCount++;
						} else {
							failCount++;
						}
					}

				}

				total = passCount + failCount;
				passPercentage = decimalFormat.format((((double) passCount * 100) / (double) total));
				failPercentage = decimalFormat.format((((double) failCount * 100) / (double) total));
				featureWiseSummary.put("FeatureName", featureFileName);
				featureWiseSummary.put("PassCount", "" + passCount);
				featureWiseSummary.put("FailCount", "" + failCount);
				featureWiseSummary.put("Total", "" + total);
				featureWiseSummary.put("PassPercentage", passPercentage + "%");
				featureWiseSummary.put("FailPercentage", failPercentage + "%");
				summary.add(featureWiseSummary);
				totalTestCase = totalTestCase + total;
				totalPass = totalPass + passCount;
				totalFail = totalFail + failCount;
			}

			totalTestCase = totalPass + totalFail;
			totalPassPercentage = decimalFormat.format((((double) totalPass * 100) / (double) totalTestCase)) + "%";
			totalFailPercentage = decimalFormat.format((((double) totalFail * 100) / (double) totalTestCase)) + "%";

		} catch (Exception e) {
			System.out.println("Exception occurred while validating JSON file is empty or not " + e);
			// return false;
		}

	}

	/**
	 * This method will generate HTML report to be sent through email after
	 * execution.
	 * 
	 * @param allResult
	 * @param environment
	 * @throws IOException
	 * @author Rakesh Ghosal
	 */
	public static void createHtmlReport(List<HashMap<String, String>> allResult, String environment)
			throws IOException {
		String htmlString = "<!doctype html>" + "<html>" + "<head>" + "<style>" + "table {"
				+ "font-family: calibri, sans-serif;" + "border-collapse: collapse;" + "width: 70%;" + "}" +

				"td {" + "text-align: left;" + "padding: 3px;" + "}" + "th {" + "border: 1px;" + "padding: 5px;" + "}" +

				"</style>" + "</head>" + "<body>" + "<table border=\"1\">" + "<tbody>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">DIGITAL TEST REPORT "
				+ environment + "</font></th>" + "</tr>" + "<tr>";

		/*htmlString = htmlString + "</tr>" + "<tr>" + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>"
				+ "</tr>" + "<tr>" + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Summary</font></th>"
				+ "</tr>" + "<tr>" + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Metrices</font></th>"
				+ "</tr>";*/
		htmlString = htmlString + "</tr>" + "<tr>" + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>"
				+ "</tr>"  + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Features : Test Execution Results</font></th>"
				+ "</tr>";

		htmlString = htmlString + "<tr>" + "<td colspan=\"3\"><b>Feature Name</b></td>"
				+ "<td colspan=\"1\"><b>Total Scenario</b></td>" + "<td colspan=\"1\"><b>Passed</b></td>"
				+ "<td colspan=\"1\"><b>Failed</b></td>" + "<td colspan=\"1\"><b>Pass Percentage</b></td>"
				+ "<td colspan=\"1\"><b>Fail Percentage</b></td>" + "</tr>";

		for (int i = 0; i < summary.size(); i++) {
			htmlString = htmlString + "<tr>";
			htmlString = htmlString + "<td colspan=\"3\">" + summary.get(i).get("FeatureName") + "</td>";
			htmlString = htmlString + "<td colspan=\"1\">" + summary.get(i).get("Total") + "</td>";
			htmlString = htmlString + "<td colspan=\"1\">" + summary.get(i).get("PassCount") + "</td>";
			htmlString = htmlString + "<td colspan=\"1\">" + summary.get(i).get("FailCount") + "</td>";
			htmlString = htmlString + "<td colspan=\"1\">" + summary.get(i).get("PassPercentage") + "</td>";
			htmlString = htmlString + "<td colspan=\"1\">" + summary.get(i).get("FailPercentage") + "</td>";
			htmlString = htmlString + "</tr>";
		}

		htmlString = htmlString + "<tr>" + "<td colspan=\"3\"><b>Total</b></td>" + "<td colspan=\"1\"><b>"
				+ totalTestCase + "</b></td>" + "<td colspan=\"1\"><b>" + totalPass + "</b></td>"
				+ "<td colspan=\"1\"><b>" + totalFail + "</b></td>" + "<td colspan=\"1\"><b>" + totalPassPercentage
				+ "</b></td>" + "<td colspan=\"1\"><b>" + totalFailPercentage + "</b></td>" + "</tr>";

		/*htmlString = htmlString + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Scenario Execution Details</font></th>"
				+ "</tr>" + "<tr>" + "<td colspan=\"2\"><b>Feature Name</b></td>"
				+ "<td colspan=\"2\"><b>Scenario Name</b></td>" + "<td colspan=\"2\"><b>Status</b></td>"
				+ "<td colspan=\"2\"><b>Failure Reason</b></td>" + "</tr>";*/
		htmlString = htmlString + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Scenarios : Test Execution Results</font></th>"
				+ "</tr>" + "<tr>" + "<td colspan=\"3\"><b>Feature Name</b></td>"
				+ "<td colspan=\"3\"><b>Scenario Name</b></td>" + "<td colspan=\"2\"><b>Status</b></td>"
				+ "</tr>";

		for (int i = 0; i < allResult.size(); i++) {
			htmlString = htmlString + "<tr>";
			htmlString = htmlString + "<td colspan=\"3\">" + allResult.get(i).get("Feature_Name") + "</td>";
			htmlString = htmlString + "<td colspan=\"3\">" + allResult.get(i).get("Scenario_Name") + "</td>";
			htmlString = htmlString + "<td colspan=\"2\">" + allResult.get(i).get("Status") + "</td>";
			//htmlString = htmlString + "<td colspan=\"2\">" + allResult.get(i).get("Error") + "</td>";
			htmlString = htmlString + "</tr>";
		}
		
		htmlString = htmlString + "<th align=\"center\" bgcolor=\"FFFFFF\" colspan=\"8\"></th>" + "</tr>" + "<tr>"
				+ "<th align=\"center\" bgcolor=\"333300\" colspan=\"8\"><font color=\"FFFF00\">Detailed test execution report</font></th>"
				+ "</tr>" + "<tr>" + "<td colspan=\"4\"><b>Type of Report</b></td>"
				+ "<td colspan=\"4\"><b>Jenkins Link</b></td>" + "</tr>";
		String[] typeofReport ={"Standard Cucumber Reports","ClueCumber Reports"};
		String[] jenkinsLinks = {"<a href='http://10.124.253.96:8080/job/Digital/job/BDD/job/Savingtools1//" + System.getenv("BUILD_NUMBER") +"/cucumber-html-reports/overview-features.html'>Cucumber Reports</a>","<a href='http://10.124.253.96:8080/job/Digital/job/BDD/job/Savingtools1/HTML_20Report/'>ClueCumber Reports</a>"};
		for (int i = 0; i < 2; i++) {
			htmlString = htmlString + "<tr>";
			htmlString = htmlString + "<td colspan=\"4\">" + typeofReport[i] + "</td>";
			htmlString = htmlString + "<td colspan=\"4\">" + jenkinsLinks[i] + "</td>";
			htmlString = htmlString + "</tr>";
		}
		htmlString = htmlString + "</tbody>" + "</table>" + "</body>" + "</html>";
		System.out.println("Emailable Report Generated");

		Document doc = Jsoup.parse(htmlString, "utf-8");
		String outputFilePath = System.getProperty("user.dir") + "//target//emailableReport.html";
		System.out.println("Output File Path = " + outputFilePath);
		FileUtils.writeStringToFile(new File(outputFilePath), doc.outerHtml(), "UTF-8");

	}

}
