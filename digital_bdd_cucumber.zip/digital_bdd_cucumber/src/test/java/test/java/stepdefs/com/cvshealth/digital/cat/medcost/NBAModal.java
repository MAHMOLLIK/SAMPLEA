package test.java.stepdefs.com.cvshealth.digital.cat.medcost;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.cat.savingtools.SavingTools;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class NBAModal extends AbstractStepDefinition {
	
	SavingTools sv = new SavingTools();
	
	@Given("^user launched \\\"([^\\\"]*)\\\" and logged in with valid credentials \"([^\"]*)\",\"([^\"]*)\"$")
	public void user_launched_and_logged_in_with_valid_credentials(String cvs_url, String username, String password) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(cvs_url));
			Assert.assertTrue("URL " + PropertyFileLoader.getInstance().getProperty(cvs_url) + " navigated successfully", OperationsDesktop.navigateURL(executionContext));
						
			username=executionContext.getExecutionData("username", username);
			password=executionContext.getExecutionData("password", password);
			
		    String usernameXpath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_EmailAddress", Browser);
		    executionContext.setXpathDataPair(usernameXpath, username);
		    OperationsDesktop.wait_For_Object(executionContext);
		    OperationsDesktop.input(executionContext);
			
			String passwordXPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_Password", Browser);
			executionContext.setXpathDataPair(passwordXPath, password);
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String signInXPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wBtn_SignIn", Browser);
			executionContext.setXpathDataPair(signInXPath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
		
			String descriptionMessageXPath = ExecutionContext.getObjectLocator("Welcome_Message", "wLnk_access", Browser);
			executionContext.setXpathDataPair(descriptionMessageXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.mouse_Hover(executionContext);
			OperationsDesktop.click(executionContext);
			
			String welcomeMessageXPath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage", "wBtn_ModalOkay", Browser);
			executionContext.setXpathDataPair(welcomeMessageXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.mouse_Hover(executionContext);
			OperationsDesktop.click(executionContext);
			Thread.sleep(18000);


		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^user should able to see glucometer message \\\"([^\\\"]*)\\\"$")
	public void user_should_able_to_see_glucometer_message(String glucometer_message) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Glucose", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, glucometer_message);
			OperationsDesktop.validate_Object_Text(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user clicks on find out more link$")
	public void user_clicks_on_find_out_more_link() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String findoutmoreXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wLnk_FindoutMore", Browser);
			executionContext.setXpathDataPair(findoutmoreXpath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
	
	@Then("^user should able to see free glucometer information request window$")
	public void user_should_able_to_see_free_glcometer_information_request_window() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String glucometerInfoXpath = ExecutionContext.getObjectLocator("NBA_Message","wTxT_Modal_info", Browser);
			executionContext.setXpathDataPair(glucometerInfoXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user is landed on pharmacy dashboard$")
	public void user_is_landed_on_pharmacy_dashboard() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			executionContext.setCurrentElementData("5000");
			OperationsDesktop.wait(executionContext);

			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_PharmacyPage","wElt_MyPrescriptions", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, "");
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	 
	}
	
	@Then("^user can close information window$")
	public void user_can_close_information_window() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String closeWindowInfoXpath = ExecutionContext.getObjectLocator("NBA_Message","wBtn_close", Browser);
			executionContext.setXpathDataPair(closeWindowInfoXpath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^verify glucometer offer banner is displayed or not based on data \\\"([^\\\"]*)\\\"$")
	public void verify_glucometer_offer_banner_is_displayed_or_not_based_on_data(String is_glucometer_banner_shown) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			if(is_glucometer_banner_shown.equalsIgnoreCase("yes")) {
				verify_glucometer_banner_is_displayed();
			} else {
				verify_glucometer_banner_is_not_displayed();
			}
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^verify statin offer banner is displayed or not based on data \\\"([^\\\"]*)\\\"$")
	public void verify_statin_offer_banner_is_displayed_or_not_based_on_data(String is_statin_banner_shown) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			if(is_statin_banner_shown.equalsIgnoreCase("yes")) {
				verify_statin_banner_is_displayed();
			} else {
				verify_statin_banner_is_not_displayed();
			}
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	public void verify_glucometer_banner_is_displayed() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Glucose", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, "");
			OperationsDesktop.exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	public void verify_glucometer_banner_is_not_displayed() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Glucose", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, "");
			OperationsDesktop.not_Exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^user clicks on No Thank you link$")
	public void user_clicks_on_No_Thank_you_link() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String noThankYouXPath = ExecutionContext.getObjectLocator("NBA_Message", "wBtn_NoThankyou", Browser);
			executionContext.setXpathDataPair(noThankYouXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			OperationsDesktop.click_Object_If_Exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

//	@Then("^verify glucometer request is not process and user is landed on pharmacy dashboard$")
//	public void verify_glucometer_request_is_not_process() {
//		
//		reportUtility.performInitialSetupForStep(executionContext);
//		try {
//			user_is_landed_on_pharmacy_dashboard();
//			
//		} catch (Exception e) {
//			ExceptionHandler.handleException(e);
//			reportUtility.setStatusOfOperationForStep(executionContext, false);
//		}
//		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
//	}
	
	@When("^user request for free glucometer$")
	public void user_request_for_free_glucometer() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String requestGlucometerXPath = ExecutionContext.getObjectLocator("NBA_Message", "wBtn_requestGlucometer", Browser);
			executionContext.setXpathDataPair(requestGlucometerXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			OperationsDesktop.click_Object_If_Exist(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^click continue for leaving cvs dot com$")
	public void click_continue_for_leaving_cvs_dot_com() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String continueXPath = ExecutionContext.getObjectLocator("NBA_Message", "wBtn_Continue", Browser);
			executionContext.setXpathDataPair(continueXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			OperationsDesktop.click_Object_If_Exist(executionContext);
			Thread.sleep(8000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	public void verify_statin_banner_is_displayed() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Statin", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, "");
			OperationsDesktop.exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	public void verify_statin_banner_is_not_displayed() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Statin", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, "");
			OperationsDesktop.not_Exist(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^user is able to see statin message \\\"([^\\\"]*)\\\"$")
	public void user_is_able_to_see_statin_message(String statin_message) {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String pharmacyDaashboardPage = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wTxt_Banner_Message_Statin", Browser);
			executionContext.setXpathDataPair(pharmacyDaashboardPage, statin_message);
			OperationsDesktop.validate_Object_Text(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user click on Get help now link$")
	public void user_click_on_Get_help_now_link() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String getHelpLinkXpath = ExecutionContext.getObjectLocator("ICE_Pharmacy_HomePage","wLnk_GethelpNow", Browser);
			executionContext.setXpathDataPair(getHelpLinkXpath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user should able to see statin information window to consult prescriber$")
	public void user_should_able_to_see_statin_information_window_to_consult_prescriber() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String statinInfoModalXpath = ExecutionContext.getObjectLocator("NBA_Message","wTxT_Modal_info", Browser);
			executionContext.setXpathDataPair(statinInfoModalXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user click on consult prescriber$")
	public void user_click_on_consult_prescriber() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String statinRequestXpath = ExecutionContext.getObjectLocator("NBA_Message","wBtn_requestStatin", Browser);
			executionContext.setXpathDataPair(statinRequestXpath, "");
			OperationsDesktop.click_Object_If_Exist(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
	
	
	@Then("^user should able to see request received confirmation page with Pharmacy and Prescriber details$")
	public void user_should_able_to_see_request_received_confirmation_page_with_Pharmacy_and_Prescriber_details() {
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String statinRequestXpath = ExecutionContext.getObjectLocator("NBA_Message","wMsg_statinResponse", Browser);
			executionContext.setXpathDataPair(statinRequestXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			Thread.sleep(13000);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Given("^User with \"([^\"]*)\", \"([^\"]*)\" is in pharmacy dashboard$")
	public void user_is_in_pharmacy_dashboard(String userName, String password) {

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// user sign in
			sv.cvs_dot_com_user_logged_into_ICE_Pharmacy_using_valid_credentials(userName, password);
			this.user_is_landed_on_pharmacy_dashboard();
			Thread.sleep(8000);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
}
