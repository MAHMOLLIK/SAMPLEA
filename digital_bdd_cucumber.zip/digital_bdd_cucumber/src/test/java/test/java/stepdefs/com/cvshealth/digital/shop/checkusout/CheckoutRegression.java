package test.java.stepdefs.com.cvshealth.digital.shop.checkusout;

import org.junit.Assert;
import org.openqa.selenium.By;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class CheckoutRegression extends AbstractStepDefinition {

	@Given("^user navigate \"([^\"]*)\" that has a product in basket already$")
	public void user_navigate_that_has_a_product_in_basket_already(String BB_URL) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(BB_URL));
			Assert.assertTrue("URL " + PropertyFileLoader.getInstance().getProperty(BB_URL) + " navigated successfully",
					OperationsDesktop.navigateCustomURL(executionContext));

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Given("^user clicks checkout now$")
	public void user_clicks_checkout_now() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// clicks to add to basket
			String AddToBasket = ExecutionContext.getObjectLocator("Card_Page", "QA1_AddToBasket", Browser);
			executionContext.setXpathDataPair(AddToBasket, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

			// click checkout
			String wBtn_Checkout = ExecutionContext.getObjectLocator("Checkout_Page", "wBtn_CheckoutButton", Browser);
			executionContext.setXpathDataPair(wBtn_Checkout, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

			// click checkout now
			String wBtn_CheckoutNow = ExecutionContext.getObjectLocator("Checkout_Page", "wBtn_CheckoutNow", Browser);
			executionContext.setXpathDataPair(wBtn_CheckoutNow, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Given("^user enter a valid shipping address$")
	public void user_enter_a_valid_shipping_address() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			// user provides shipping info
			String wBtn_Signin = ExecutionContext.getObjectLocator("Checkout_Page", "Input_FullName", Browser);
			executionContext.setXpathDataPair(wBtn_Signin, "Sukanta Saha");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String Input_StreetAddress = ExecutionContext.getObjectLocator("Checkout_Page", "Input_StreetAddress",
					Browser);
			executionContext.setXpathDataPair(Input_StreetAddress, "123 Main Street");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String Input_Apartment = ExecutionContext.getObjectLocator("Checkout_Page", "Input_Apartment", Browser);
			executionContext.setXpathDataPair(Input_Apartment, "A");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String Input_City = ExecutionContext.getObjectLocator("Checkout_Page", "Input_City", Browser);
			executionContext.setXpathDataPair(Input_City, "Cincinnati");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String Input_State = ExecutionContext.getObjectLocator("Checkout_Page", "Input_State", Browser);
			executionContext.setXpathDataPair(Input_State, "OH");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.select_Listbox_Option_By_Value(executionContext);

			String Input_Zipcode = ExecutionContext.getObjectLocator("Checkout_Page", "Input_Zipcode", Browser);
			executionContext.setXpathDataPair(Input_Zipcode, "45209");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String Input_Email = ExecutionContext.getObjectLocator("Checkout_Page", "Input_Email", Browser);
			executionContext.setXpathDataPair(Input_Email, "saha4311@gmail.com");
			// OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String wBtn_ContinuePayment = ExecutionContext.getObjectLocator("Checkout_Page", "wBtn_ContinuePayment",
					Browser);
			executionContext.setXpathDataPair(wBtn_ContinuePayment, "");
			OperationsDesktop.click(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Given("^user enters a valid payemnt information$")
	public void user_enters_a_valid_payemnt_information() {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			/*String Click_To_Reload = ExecutionContext.getObjectLocator("Checkout_Page", "Click_To_Reload", Browser);
			executionContext.setXpathDataPair(Click_To_Reload, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click_Object_If_Exist(executionContext);*/

			String Switch_Iframe2 = ExecutionContext.getObjectLocator("Checkout_Page", "Switch_Iframe2", Browser);
			executionContext.setXpathDataPair(Switch_Iframe2, "");
			OperationsDesktop.wait_For_Object(executionContext);
			Thread.sleep(3000);
			OperationsDesktop.switch_To_Frame_By_Object(executionContext);

			String Input_Card = ExecutionContext.getObjectLocator("Checkout_Page", "Input_Card", Browser);
			executionContext.setXpathDataPair(Input_Card, "5555555555554444");
			OperationsDesktop.input(executionContext);

			String Exp_Month = ExecutionContext.getObjectLocator("Checkout_Page", "Exp_Month", Browser);
			executionContext.setXpathDataPair(Exp_Month, "01");
			OperationsDesktop.select_Listbox_Option_By_Value(executionContext);

			String Exp_Year = ExecutionContext.getObjectLocator("Checkout_Page", "Exp_Year", Browser);
			executionContext.setXpathDataPair(Exp_Year, "20");
			OperationsDesktop.select_Listbox_Option_By_Value(executionContext);

			String Input_CVV = ExecutionContext.getObjectLocator("Checkout_Page", "Input_CVV", Browser);
			executionContext.setXpathDataPair(Input_CVV, "154");
			OperationsDesktop.input(executionContext);

			executionContext.getDriver().switchTo().parentFrame();
			// executionContext.getDriver().switchTo().defaultContent();

			String wBtn_ContonueReview = ExecutionContext.getObjectLocator("Checkout_Page", "wBtn_ContonueReview",
					Browser);
			executionContext.setXpathDataPair(wBtn_ContonueReview, "");
			OperationsDesktop.wait_For_Object(executionContext);
			// OperationsDesktop.click_Java_Script(executionContext);
			OperationsDesktop.click(executionContext);

			String wBtn_PlaceOrder = ExecutionContext.getObjectLocator("Checkout_Page", "wBtn_PlaceOrder", Browser);
			executionContext.setXpathDataPair(wBtn_PlaceOrder, "");
			OperationsDesktop.wait_For_Object(executionContext);
			// OperationsDesktop.click_Java_Script(executionContext);
			OperationsDesktop.click(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user lunches new \"([^\"]*)\"$")
	public void user_lunches_new(String FSA_URL) throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(FSA_URL));
			Assert.assertTrue(
					"URL " + PropertyFileLoader.getInstance().getProperty(FSA_URL) + " navigated successfully",
					OperationsDesktop.navigateCustomURL(executionContext));

			// clicks to add to basket
			String AddToBasket = ExecutionContext.getObjectLocator("Card_Page", "QA1_AddToBasket", Browser);
			executionContext.setXpathDataPair(AddToBasket, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

}
