package test.java.stepdefs.com.cvshealth.digital.library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;


/** 
* <p style="font-family:Arial;">
* <b>DESCRIPTION: This Singleton Class creates Database connection and fetches all required data in hash maps
* <br><br>
* Author: - ACOE Team
* <br><br>
* Date Created: 05/03/2019
* <br><br>Revision History: 
* </b></P> 
* 
*/

public class DBCacheSingleton {
	
	//This method is used to store Maria_DB_Driver path
	private final String  MARIA_DB_DRIVER_PATH="org.mariadb.jdbc.Driver";
	
	//This member variable is used to store current class object
	private static DBCacheSingleton objDBCache=null;
	
	//This member variable is used to store Maria DB IP
	private String MARIA_DB_IP;
	
	//This member variable is used to store Maria DB User
	private String MARIA_DB_USER;
	
	//This member variable is used to store Maria DB Password
	private String MARIA_DB_PASSWORD;
	
	//This member variable is used to store current data base object
	private String currentDataBase;
	
	//This member variable is used to store current DB connection URL
	private String MARIA_DB_URL;
	
	//This hash map stores all the object repository data
	private HashMap<String, String> hashMapObjectRepositoryData=new HashMap<>();
	
	//This hash map stores all the test execution data
	private HashMap<String, String> hashMapTestExecutionData=new HashMap<>();
	
	
	//This is the default constructor of DBCacheSingleton class
	private DBCacheSingleton() {
		
		//This method is used to read data base property from PropertyFileLoader class
		fetchAttributesFromPropertyLoader();
		
		//This method is used to build Maria DB URL
		buildMARIA_DB_URL();
		
		//This method us used to fetch object repository data from Maria DB
		fetchObjectRepositoryFromDB();
		
		//This method us used to fetch test execution data from Maria DB
		fetchTestDataFromDB();
		
	}
	
	
	/*
	 * =========================================================================================== 
	 * Function Name: getInstance
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get object of singleton class DBCacheSingleton
	 * Parameter: Nothing
	 * RETURNS: Object of DBCacheSingleton class
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get object of singleton class DBCacheSingleton
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Object of DBCacheSingleton class
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public static DBCacheSingleton getInstance(){
		 if (objDBCache == null) {
			 objDBCache = new DBCacheSingleton(); 	  
		 }
	        return objDBCache; 
	}
	
	
	/*
	 * =========================================================================================== 
	 * Function Name: buildMARIA_DB_URL
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to set MariaDB connection URL
	 * Parameter: Nothing
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to set MariaDB connection URL
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Nothing
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	private void buildMARIA_DB_URL() {
		//Set data base connection URL
		MARIA_DB_URL="jdbc:mariadb://"+MARIA_DB_IP+":3306/" + currentDataBase;
		Log.writeToLogFile("Maria DB Connection URL: "+MARIA_DB_URL);
		
	}

	
	
	/*
	 * =========================================================================================== 
	 * Function Name: fetchAttributesFromPropertyLoader
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to fetch Maria DB details from property files
	 * Parameter: Nothing
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to fetch Maria DB details from property files
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Nothing
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public void fetchAttributesFromPropertyLoader() {
		//Fetch Maria DB properties
		MARIA_DB_IP=PropertyFileLoader.getInstance().getMARIA_DB_IP();
		Log.writeToLogFile("Maria DB IP: "+MARIA_DB_IP);
		
		MARIA_DB_USER=PropertyFileLoader.getInstance().getMARIA_DB_USER();
		Log.writeToLogFile("Maria DB User: "+MARIA_DB_USER);
		
		MARIA_DB_PASSWORD=PropertyFileLoader.getInstance().getMARIA_DB_PASSWORD();
		currentDataBase=PropertyFileLoader.getInstance().getDB();
		Log.writeToLogFile("Maria DB Schema: "+currentDataBase);
		
		
	}
	
	/*
	 * =========================================================================================== 
	 * Function Name: fetchTestDataFromDB
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to fetch test data from Maria DB
	 * Parameter: Nothing
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to fetch test data from Maria DB
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Nothing
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	private void fetchTestDataFromDB() {	
		
		try {

			String dataSourceStatus = PropertyFileLoader.getInstance().getProperty("FETCH_DATA_FROM_DB");
			
			if (dataSourceStatus != null && dataSourceStatus.equalsIgnoreCase("YES")) {

				//Query to get data from Maria DB
				
				String query = "select * from testdata_cvs ";
				Log.writeToLogFile("Query to get data from table testdata_cvs from Maria DB: "+query);
				
				// Data base connection to get data from Maria DB
				Connection connection = getConnection();

				// Objects to get data from Data Base
				Statement objStatement = connection.createStatement();
				ResultSet resultset = objStatement.executeQuery(query);

				if (resultset != null) {
					while (resultset.next()) {
						String featureName = resultset.getString("FEATURE_NAME");

						if (featureName != null) {
							featureName = featureName.toUpperCase();
						}
						String scenarioName = resultset.getString("SCENARIO_NAME");
						String environment = resultset.getString("ENVIRONMENT");
						int iterationNumber = Integer.parseInt(resultset.getString("ITERATION_NUMBER"));
						String colName = resultset.getString("COL_NAME");
						String colValue = resultset.getString("COL_VAL");
						hashMapTestExecutionData.put(
								featureName + "|" + scenarioName + "|" + environment + "|" + colName + iterationNumber,
								colValue);
						Log.writeToLogFile(featureName + "|" + scenarioName + "|" + environment + "|" + colName
								+ iterationNumber + " and value is " + colValue);
					}
				}
				Log.writeToLogFile("Number of data in object reposity hash map: " + hashMapTestExecutionData.size());
				resultset.close();
				connection.close();
			}
			else{
				Log.writeToLogFile("hashMapTestExecutionData not loaded as 'FETCH_DATA_FROM_DB' property is set to :"+dataSourceStatus);
			}

		}catch (Exception e) {
			ExceptionHandler.handleException(e);
		} 
		
	}
	/*
	 * =========================================================================================== 
	 * Function Name: fetchTestDataFromDB
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to fetch object repository data from Maria DB
	 * Parameter: Nothing
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to fetch object repository data from Maria DB
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Nothing
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	private void fetchObjectRepositoryFromDB() {	
		//Query to get data from object repository table
		String query = "select * from object_repository_desktop_cvs";
		Log.writeToLogFile("Query to get data from Object repository table: "+query);
		try{
			Connection connection=getConnection();
			
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);

			if(resultset!=null)
			{
				while(resultset.next())
				{
					String ScreenName = resultset.getString("SCREEN_NAME");
					String ObjectName = resultset.getString("OBJECT_NAME");
					String IEXPath = resultset.getString("IE_XPATH"); 
					String FireFoxPath = resultset.getString("FIREFOX_XPATH"); 
					String ChromeXPath = resultset.getString("GOOGLECHROME_XPATH"); 
					String EdgeXPath = resultset.getString("EDGE_XPATH");
					String safariXPath =resultset.getString("SAFARI_XPATH");
					//String safariLocator =resultset.getString("SAFARI_LOCATORTYPE");
					
					hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+ "|"+  "IE",IEXPath);
					hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+"|"+  "FIREFOX",FireFoxPath);
					hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+"|"+ "GOOGLECHROME",ChromeXPath);
					hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+"|"+ "EDGE",EdgeXPath);
					hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+"|"+ "SAFARI",safariXPath);
					//hashMapObjectRepositoryData.put(ScreenName+"|"+ObjectName+"|"+ "SAFARI",safariLocator);
					
				}
			}
			
			Log.writeToLogFile("Number of data in object reposity hash map: "+hashMapObjectRepositoryData.size());
			resultset.close();
			connection.close();
			
			}catch (Exception e) {
				ExceptionHandler.handleException(e);
			} 
		
	}


	/*
	 * =========================================================================================== 
	 * Function Name: getConnection
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get MariaDB connection to get data from data base
	 * Parameter: Nothing
	 * RETURNS: Object of Connection class
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get MariaDB connection to get data from data base
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No argument
	* @return Object of Connection class
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	private Connection getConnection() {
		Connection connection = null;
    	try {
			Class.forName(MARIA_DB_DRIVER_PATH);
			connection = DriverManager.getConnection(MARIA_DB_URL,MARIA_DB_USER,MARIA_DB_PASSWORD);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}  
    	
    	return connection;
		
	}

	
	/**
	 * Added getter and setter
	 * @return
	 */

	public HashMap<String, String> getHashMapObjectRepositoryData() {
		return hashMapObjectRepositoryData;
	}


	public void setHashMapObjectRepositoryData(HashMap<String, String> hashMapObjectRepositoryData) {
		this.hashMapObjectRepositoryData = hashMapObjectRepositoryData;
	}


	public HashMap<String, String> getHashMapTestExecutionData() {
		return hashMapTestExecutionData;
	}


	public void setHashMapTestExecutionData(HashMap<String, String> hashMapTestExecutionData) {
		this.hashMapTestExecutionData = hashMapTestExecutionData;
	}



}
