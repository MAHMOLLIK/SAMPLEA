package test.java.stepdefs.com.cvshealth.digital.shop.checkusout;

//import java.util.List;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
//import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;


public class DemoCheckout extends AbstractStepDefinition {
	
	
	@Given("^user should be on homepage to cvs$")
	public void user_should_be_on_homepage_to_cvs() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//navigateUrl - set url to execution context
			//set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getURL()+ " navigated successfully", OperationsDesktop.navigateURL(executionContext));
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user clicks sign in button$")
	public void user_clicks_sign_in_button() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//set current xpath and current data for input function
			//String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_Password",Browser);
			String wBtn_Signin = ExecutionContext.getObjectLocator("Home_Page", "wBtn_Signin", Browser);
			executionContext.setXpathDataPair(wBtn_Signin, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user enters valid \"([^\"]*)\" that associated with the particuler account$")
	public void user_enters_valid_that_associated_with_the_particuler_account(String arg1) throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			// Get required data from data base
			arg1 = executionContext.getExecutionData("email", arg1);
				
			String Input_Email = ExecutionContext.getObjectLocator("Singin_Page", "Input_Email", Browser);
			executionContext.setXpathDataPair(Input_Email, arg1);
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^clicks continue$")
	public void clicks_continue() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//set current xpath and current data for input function
			//String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_Password",Browser);
			String wBtn_Continue = ExecutionContext.getObjectLocator("Singin_Page", "wBtn_Continue", Browser);
			executionContext.setXpathDataPair(wBtn_Continue, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^user enters a valid \"([^\"]*)\" that associated with the particuler account$")
	public void user_enters_a_valid_that_associated_with_the_particuler_account(String arg1) throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			arg1 = executionContext.getExecutionData("password", arg1);
			
			String Input_Password = ExecutionContext.getObjectLocator("Singin_Page", "Input_Password", Browser);
			executionContext.setXpathDataPair(Input_Password, arg1);
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
	
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^clicks signin$")
	public void clicks_signin() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			//set current xpath and current data for input function
			//String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_Password",Browser);
			String wBtn_Signin = ExecutionContext.getObjectLocator("Singin_Page", "wBtn_Signin", Browser);
			executionContext.setXpathDataPair(wBtn_Signin, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^user verifies welcome text$")
	public void user_verifies_welcome_text() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String Text_Welcome = ExecutionContext.getObjectLocator("Singin_Page", "Text_Welcome", Browser);
			executionContext.setXpathDataPair(Text_Welcome, "Welcome CVS!");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.validate_Object_Text(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

}

