package test.java.stepdefs.com.cvshealth.digital.orm.orderstatusaurus;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;

public class OrderStatus extends AbstractStepDefinition {
	
	@Given("^CMK dot com user logged into ICE Portal using valid credentials$")
	public void cmk_dot_com_user_logged_into_ICE_Portal_using_valid_credentials(DataTable objDataTable) {
		System.out.println("objdatatable file data: "+objDataTable.toString());
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//Get required data 
			String userName=executionContext.getExecutionData(objDataTable, "username");
			String password=executionContext.getExecutionData(objDataTable, "password");	
			
			/*for each method call, user should set xpath-data pair and then call method
			pass empty string respectively when xpath/data is not required to call the method*/
			
			//navigateUrl - set url to execution context
			//set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue(OperationsDesktop.navigateURL(executionContext));
			Thread.sleep(30000); //this is defined to invoke https://icet-sit1.caremark.com?iceenv=sit2 manually and then CMK URL will be launched
			
			
			//set xpath for Username object and input
			String userNameXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage","wEdt_Username",Browser);			
			executionContext.setXpathDataPair(userNameXPath, userName);
			
			//both the operations can be invoked sequentially as both require same xPath and data which has been set already
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);		
			
			//click in Password text box
			String userPasswordtextxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage","wEdt_PasswordPlaceholder",Browser);
			executionContext.setXpathDataPair(userPasswordtextxPath, "");
			OperationsDesktop.click(executionContext);
			
			//set xpath for Password object and input
			String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage","wEdt_Password",Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			//click SignIn
			String signInButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage","wBtn_SignIn",Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);
			
			//wait_For_Object
			String signoutButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_LogOut",Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	
	
	@Given("^navigates to Your Orders screen using view order status option under Prescriptions$")
	public void navigates_to_Your_Orders_screen_using_view_order_status_option_under_Prescriptions() {
		// Write code here that turns the phrase above into concrete actions
				reportUtility.performInitialSetupForStep(executionContext);
				try {
					String prescriptionsXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_MM_Prescriptions",Browser);
					executionContext.setXpathDataPair(prescriptionsXPath, "");
					OperationsDesktop.mouse_Hover(executionContext);
					
					String viewOrderStatusLinks=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_MM_ViewOrderStatus",Browser);
					executionContext.setXpathDataPair(viewOrderStatusLinks, "");
					OperationsDesktop.click(executionContext);
					
					String yourOrders=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wTxt_YourOrders",Browser);
					executionContext.setXpathDataPair(yourOrders, "");
					OperationsDesktop.wait_For_Object(executionContext);
					Thread.sleep(50000);
					
				} catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);

				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			}
	

@When("^Your Orders screen is loaded in iframe component$")
public void your_Orders_screen_is_loaded_in_iframe_component()  {
    // Write code here that turns the phrase above into concrete actions
	
	try{
	//String iframeName=executionContext.getExecutionData(objDataTable, "iframe_name");
	String iframeName=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrdersPage","wElt_iFrame",Browser);
	executionContext.setXpathDataPair(iframeName, "");
	OperationsDesktop.switch_To_Frame_By_Object(executionContext);
	Thread.sleep(50000);
    
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}


@Then("^Your Orders screen should be loaded succesfully$")
public void your_orders_screen_should_be_loaded_succesfully() {

	try {
				
	   // String wMsg_dateRange = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wMsg_dateRange", Browser);
		//executionContext.setXpathDataPair(wMsg_dateRange, ", 2019");
		
		String wTxt_introText = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wTxt_introText", Browser);
		executionContext.setXpathDataPair(wTxt_introText, "Prescription orders placed recently are shown here. Check below for current order status or for details of those already fulfilled.");
		OperationsDesktop.validate_Object_Text(executionContext);
		
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}

		





/***********************************************************************************************************************
 * Second Scenario
 * 
 ************************************************************************************************************************/

@Given("^user clicks on request a new prescription screen option under Prescriptions$")
public void user_clicks_on_request_a_new_prescription_screen_option_under_Prescriptions() {
	
	// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String prescriptionsXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_MM_Prescriptions",Browser);
			executionContext.setXpathDataPair(prescriptionsXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			String requestNewPrescriptionLinks=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_MM_RequestNewPrescription",Browser);
			executionContext.setXpathDataPair(requestNewPrescriptionLinks, "");
			OperationsDesktop.click(executionContext);

		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

@Given("^Request New Prescription Screen is loaded in iframe component$")
public void Request_New_Prescription_Screen_is_loaded_in_iframe_component() {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		String iframeXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescription","wElt_iFrame",Browser);
		executionContext.setXpathDataPair(iframeXPath, "");
		OperationsDesktop.switch_To_Frame_By_Object(executionContext);
		Thread.sleep(20000);
					
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

}


@Given("^Request a New Prescription header is displayed$")
public void Request_New_Prescription_header_is_displayed() {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {

			String requestNewPrescriptionsXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescription","wTxt_RequestaNewPrescription",Browser);
			executionContext.setXpathDataPair(requestNewPrescriptionsXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

		}


@When("^user search for \"([^\"]*)\" and selects drug \"([^\"]*)\" from search results$")
public void user_search_for_and_selects_drug_from_search_results(String drugPartialName, String drugFullName)  {
    // Write code here that turns the phrase above into concrete actions

	reportUtility.performInitialSetupForStep(executionContext);
	try{
		//Parse data as per local / Data Base
		drugPartialName=executionContext.getExecutionData("searchString", drugPartialName);
		drugFullName=executionContext.getExecutionData("selectString", drugFullName);
		
		
				
		//Get activity object / data
		
			
	
		String wInput_Drug = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage", "wInput_Drug", Browser);
		executionContext.setXpathDataPair(wInput_Drug, drugPartialName);
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.input(executionContext);
		
		
		String wSelect_Drug = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wSelect_Drug", Browser);
		wSelect_Drug=wSelect_Drug.replace("dynamic_Medication", drugFullName.trim());
		executionContext.setXpathDataPair(wSelect_Drug, drugFullName);
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.click(executionContext);
		
		String wBtn_Search = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wBtn_Search", Browser);
		executionContext.setXpathDataPair(wBtn_Search, "");
		//OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.click(executionContext);
		
		
		String wSearched_Drug = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wSearched_Drug", Browser);
		executionContext.setXpathDataPair(wSearched_Drug, "");
		Thread.sleep(30000);
		OperationsDesktop.wait_For_Object(executionContext);
		
		
			
		
		
	}
 	catch(Exception e){
 		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);
		
	}
   reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

}



@When("^click on Request New Prescription button$")
public void click_on_Request_New_Prescription_button() {
    // Write code here that turns the phrase above into concrete actions
    
	reportUtility.performInitialSetupForStep(executionContext);
	try{

		/*String wScroll_window = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wBtn_RequestNewRx", Browser);
		executionContext.setXpathDataPair(wScroll_window, "");
		Thread.sleep(20000);
		OperationsDesktop.scroll_To_Object(executionContext); */

     String wClick_RequestnewrxBtn = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wBtn_RequestNewRx", Browser);
      executionContext.setXpathDataPair(wClick_RequestnewrxBtn, "");
     OperationsDesktop.wait_For_Object(executionContext);
     OperationsDesktop.click(executionContext);


	}
 	catch(Exception e){
 		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);
		
	}
   reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

}


@Then("^prescription should be added to the cart$")
public void prescription_should_be_added_to_the_cart() {

	reportUtility.performInitialSetupForStep(executionContext);
	try{
		
		String wText_NewRxAdded = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wTxt_NewRxAdded", Browser);
		executionContext.setXpathDataPair(wText_NewRxAdded, "This prescription has been added to your order.");
		 OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.validate_Object_Text(executionContext);
		
		
	}
 	catch(Exception e){
 		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);
		
	}
   reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


@Then("^click on Checkout button$")
public void click_on_Checkout_button() {
    // Write code here that turns the phrase above into concrete actions
    
	reportUtility.performInitialSetupForStep(executionContext);
	try{
		
		
		String wClick_CheckoutBtn = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wBtn_NewRxCheckout", Browser);
	    executionContext.setXpathDataPair(wClick_CheckoutBtn, "");
	     OperationsDesktop.wait_For_Object(executionContext);
	     OperationsDesktop.click(executionContext);
	     
	     
	     String wTxt_ReviewOrder = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_RequestNewPrescriptionPage","wTxt_ReviewOrder", Browser);
		    executionContext.setXpathDataPair(wTxt_ReviewOrder, "");
		    Thread.sleep(20000);
		     OperationsDesktop.wait_For_Object(executionContext);
		    		     
	 	
	 	}
	  	catch(Exception e){
	  		ExceptionHandler.handleException(e);
	 		reportUtility.setStatusOfOperationForStep(executionContext, false);
	 		
	 	}
	    reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	 	}

		
/***********************************************************************************************************************
 * 6 ORDER-64
 * 
 ************************************************************************************************************************/

@Then ("^verify do not see your order text is displayed along with tooltip$")
public void verify_do_not_see_your_order_text_is_displayed_along_with_tooltip () {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
						
	    String wTxt_NoOrderLabel = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wTxt_NoOrderLabel", Browser);
		executionContext.setXpathDataPair(wTxt_NoOrderLabel, "Don't see your order?");
		OperationsDesktop.validate_Object_Text(executionContext);
		
		String wElt_NoOrderToolTip = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wElt_NoOrderToolTip", Browser);
		executionContext.setXpathDataPair(wElt_NoOrderToolTip, "");
		OperationsDesktop.exist(executionContext);
		
		/*String wTxt_NoOrderToolTipText = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wElt_NoOrderToolTip", Browser);
		executionContext.setXpathDataPair(wTxt_NoOrderToolTipText, "Get information on why your order is not showing.");
		OperationsDesktop.mouse_Hover(executionContext);
		OperationsDesktop.validate_Object_Text(executionContext); */
		
			
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
	
	


@Then ("^clicking on tooltip will display related informational text$")
public void clicking_on_tooltip_will_display_related_informational_text (DataTable objDataTable) {

	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		
		String wElt_NoOrderToolTip = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wElt_NoOrderToolTip", Browser);
		executionContext.setXpathDataPair(wElt_NoOrderToolTip, "");
		OperationsDesktop.mouse_Hover(executionContext); 
		
		//Expected Result defined in Feature File
		//String wTxt_informationalText=executionContext.getExecutionData(objDataTable, "Informational_text");
		
		//Tooltiptext Xpath
				
		//String wElt_NoOrderToolTiptextXpath = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_YourOrders_Page","wTxt_informationalText", Browser);
				
		//String tooltip_msg=wElt_NoOrderToolTiptextXpath.getText();
		
		
		
		//executionContext.setXpathDataPair(wElt_NoOrderToolTiptext, "wTxt_informationalText");
		
				
		//List <WebElement> dontSeeYourOrder_tooltiptext = OperationsDesktop.findElements(executionContext.getDriver(), wElt_NoOrderToolTiptext )  ;
		
	
		//String tooltip_msg = dontSeeYourOrder_tooltiptext.getText();
		
			
		//System.out.println("Tooltip message is "+tooltip_msg );
		
				
			
		
	
		
		//Assert.assertEquals(tooltip_msg, wTxt_informationalText);
		
		//System.out.println("Message verified");
			
	
		
		
		
		
		
		//executionContext.setXpathDataPair(wTxt_informationalTextxPath, wTxt_informationalText);
		//OperationsDesktop.validate_Object_Text(executionContext);
		
		
		
		
		
		
		
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
		



/***********************************************************************************************************************
 * 11 ORDER-590
 * Scenario: Validate Order Status XID Page title and field labels under Use memberID tab
 ************************************************************************************************************************/
@Given ("^user launches CMK OrderStatus XID URL$")
public void user_launches_CMK_OrderStatus_XID_URL() {

	reportUtility.performInitialSetupForStep(executionContext);
	try {

		executionContext.setXpathDataPair("", "https://sit3fast.caremark.com/digital-auth/#/ec-digital-xid");
		Assert.assertTrue(OperationsDesktop.navigateURL(executionContext));
		
		
			
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);		
	}
	
}



@Then("^verify intro text and Page title and tabs$")
public void verify_intro_text_and_Page_title_and_tabs() {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {
	
		
		
		String introText=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wTxt_IntroText",Browser);
		executionContext.setXpathDataPair(introText, "");
		OperationsDesktop.exist(executionContext);
		
		String pageTitle=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wTxt_PageTitle",Browser);
		executionContext.setXpathDataPair(pageTitle, "");
		OperationsDesktop.exist(executionContext);
		
		String memberIDTab=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wLbl_UseMemberIDTab",Browser);
		executionContext.setXpathDataPair(memberIDTab, "");
		OperationsDesktop.exist(executionContext);
		
		String RxNumTab=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wLbl_UseRxNumTab",Browser);
		executionContext.setXpathDataPair(RxNumTab, "");
		OperationsDesktop.exist(executionContext);
		
			
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
		
	


@Then("^verify Member ID and Date of birth field labels and Continue button is displayed under Use Member ID tab$")
public void verify_Member_ID_and_Date_of_birth_field_labels_and_Continue_button_is_displayed_under_Use_Member_ID_tab() {
   
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		String memberID=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wLbl_MemberID",Browser);
		executionContext.setXpathDataPair(memberID, "");
		OperationsDesktop.exist(executionContext);
		
		String dateofBirth=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wLbl_DOB",Browser);
		executionContext.setXpathDataPair(dateofBirth, "");
		OperationsDesktop.exist(executionContext);
		
		String continueButton=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wBtn_Continue",Browser);
		executionContext.setXpathDataPair(continueButton, "");
		OperationsDesktop.exist(executionContext);
		
		
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);		
	}
		
		
			
		
	}
	


/***********************************************************************************************************************
 * 12 ORDER-590
 * Scenario: Validate Error message on Order Status XID Page when Member ID and DOB is not entered
 ************************************************************************************************************************/

@Given ("^clicks on Continue button without entering member ID and DOB$")
public void clicks_on_Continue_button_without_entering_member_ID_and_DOB() {

	reportUtility.performInitialSetupForStep(executionContext);
	try {

				
		String continueButton=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wBtn_Continue",Browser);
		executionContext.setXpathDataPair(continueButton, "");
		OperationsDesktop.click(executionContext);
		Thread.sleep(20000);		
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
	

@Then("^display top line error message$")
public void display_top_line_error_message (DataTable objDataTable) {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		String errorMessage =executionContext.getExecutionData(objDataTable,"Error_Message");
		
		String wMsg_Errormessage=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wMsg_Errormessage", Browser);
		executionContext.setXpathDataPair(wMsg_Errormessage, errorMessage);
		OperationsDesktop.validate_Object_Text(executionContext);

		
		
	}catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}

	@Then("^display inline error messages to enter member ID and DOB$")
	public void display_inline_error_messages_to_enter_member_ID_and_DOB() {

		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			String wMsg_memberIDErrormessage=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wMsg_MemberIDErrormessage", Browser);
			executionContext.setXpathDataPair(wMsg_memberIDErrormessage, "Enter a member id." );
			OperationsDesktop.validate_Object_Text(executionContext);
		
				
			String wMsg_DOBErrormessage=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_OrderStatus_XIDPage","wMsg_DOBErrormessage", Browser);
			executionContext.setXpathDataPair(wMsg_DOBErrormessage, "Enter a valid date of birth." );
			OperationsDesktop.validate_Object_Text(executionContext);
		
		
			
		}catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		
		}


	}
		
		
		
}































