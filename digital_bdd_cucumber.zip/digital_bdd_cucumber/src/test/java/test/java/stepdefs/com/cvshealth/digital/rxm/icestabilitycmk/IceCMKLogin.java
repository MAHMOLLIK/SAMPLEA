package test.java.stepdefs.com.cvshealth.digital.rxm.icestabilitycmk;

import org.junit.Assert;
import org.openqa.selenium.By;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class IceCMKLogin extends AbstractStepDefinition {

	@Given("^user on \"([^\"]*)\" home page$")
	public void user_on_home_page(String CMK_URL) throws Throwable {
	    
		// Write code here that turns the phrase above into concrete actions
				reportUtility.performInitialSetupForStep(executionContext);
				try {
					
					System.out.println(System.getProperties());
					
					executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(CMK_URL));
					System.out.println(" SIT2 URL "+PropertyFileLoader.getInstance().getProperty(CMK_URL));
					Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getProperty(CMK_URL)+ " navigated successfully", OperationsDesktop.navigateURL(executionContext));
							
		    		} catch (Exception e) {
			    		ExceptionHandler.handleException(e);
				    	reportUtility.setStatusOfOperationForStep(executionContext, false);

				     }
				        reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
	
		
	@When("^user enters CMK login \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_CMK_login_and(String username, String password) throws Throwable {
	 
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			username = executionContext.getExecutionData("username", username);
			password = executionContext.getExecutionData("password", password);

		String userNameXPath = ExecutionContext.getObjectLocator("CMK_LoginPage", "wEdt_Username", Browser);
			executionContext.setXpathDataPair(userNameXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

			executionContext.setXpathDataPair(userNameXPath, username);
			OperationsDesktop.input(executionContext);

			String userPasswordtextxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage","wEdt_PasswordPlaceholder",Browser);
			executionContext.setXpathDataPair(userPasswordtextxPath, "");
			OperationsDesktop.click(executionContext);
			
			//String userPasswordxPath = ExecutionContext.getObjectLocator("CMK_LoginPage", "wEdt_Password", Browser);
			String userPasswordxPath = ExecutionContext.getObjectLocator("CMK_LoginPage", "wEdt_Password", Browser);
			
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			// click
			String signInButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoginPage", "wBtn_SignIn",
					Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);
			//wait for Page to load
			OperationsDesktop.wait_Page_Load(executionContext);

			/*
				String signoutButtonXPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage",
						"wLnk_LogOut", Browser);
				executionContext.setXpathDataPair(signoutButtonXPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
         */
			     } catch (Exception e) {
			    	ExceptionHandler.handleException(e);
				  reportUtility.setStatusOfOperationForStep(executionContext, false);

			     }

			      reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			
	}
	
	

	@Then("^user navigates to CMK Mydashboard Page$")
	public void user_navigates_to_CMK_Mydashboard_Page() throws Throwable {
	   
		System.out.println("Menu Bar verifications");
		
		
			reportUtility.performInitialSetupForStep(executionContext);
			try {
				String dashboardmenuXPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
						"wElt_MenuBar", Browser);
				executionContext.setXpathDataPair(dashboardmenuXPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				reportUtility.setStatusOfOperationForStep(executionContext, false);

			}

			reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
   
	}
	
	@Then("^user verifies Menu bar Links$")
	public void user_verifies_Menu_bar_Links() throws Throwable {
		System.out.println("Prescriptions Link");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MenuPrescriptions", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
		//--------------Next step
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MenuPlanBenefits", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
	}

	@Then("^Verify the main logo$")
	public void verify_the_main_logo() throws Throwable {
	
      System.out.println("Main Logo");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MainLogo", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
		
	}
	
	

	@Then("^user verifies the shortcuts near logo$")
	public void user_verifies_the_shortcuts_near_logo() throws Throwable {
	
     System.out.println("Message Tracker");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MessageTracker", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
         System.out.println("Check Drug");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_CheckDrug", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
		//View All prescriptions link
		
        System.out.println("Text your prescription");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardyourprescriptionXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wTxt_CMKYourPrescriptions", Browser);
			executionContext.setXpathDataPair(dashboardyourprescriptionXPath, "");
			OperationsDesktop.wait_Page_Load(executionContext);
			OperationsDesktop.exist(executionContext);
			//OperationsDesktop.click_Java_Script(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
	}
	
	
	/*
	 * #2 - Refill buttons on dashboard verifications
	 */
		
	
	
	@Then("^verify refill top button$")
	public void verify_refill_top_button() throws Throwable {
		
	
     System.out.println("Refill Top Button");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			OperationsDesktop.wait_Page_Load(executionContext);
			
			String iFramedashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wElt_iFrame_dashboard", Browser);
			executionContext.setXpathDataPair(iFramedashboardXPath, "");
			OperationsDesktop.switch_To_Frame_By_Object(executionContext);
			
			String dashboardrefilltopXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wBtn_CMKRefillTop", Browser);
			executionContext.setXpathDataPair(dashboardrefilltopXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);
			OperationsDesktop.click(executionContext);
			OperationsDesktop.wait_Page_Load(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 	
		
	}

	@Then("^verify refill bottom button$")
	public void verify_refill_bottom_button() throws Throwable {
	
		 System.out.println("Refill Bottom Button");
			
			
			reportUtility.performInitialSetupForStep(executionContext);
			try {
				String dashboardrefillbottomXPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
						"wBtn_CMKRefillBottom", Browser);
				executionContext.setXpathDataPair(dashboardrefillbottomXPath, "");
				OperationsDesktop.exist(executionContext);
			
				
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				reportUtility.setStatusOfOperationForStep(executionContext, false);

			}

		//	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 	
			
			//landing page checking
			
			System.out.println("Verify landing Review order page");
			
			
			reportUtility.performInitialSetupForStep(executionContext);
			try {
				String txtrevieworderXPath = ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
						"wTxt_CMKReviewOrder", Browser);
				executionContext.setXpathDataPair(txtrevieworderXPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				
	     	} catch (Exception e) {
				ExceptionHandler.handleException(e);
				reportUtility.setStatusOfOperationForStep(executionContext, false);

			}

			reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
	}

	@Then("^click the refill button and verify landing to review page$")
	public void click_the_refill_button_and_verify_landing_to_review_page() throws Throwable {
	
	
	
	}

	
	/*
	 * #3-ICE page verifications - Prescriptions tab
	 */
	
	
	@Then("^verify Prescriptions tab$")
	public void verify_Prescriptions_tab() throws Throwable {
	 
     System.out.println("Prescriptions Link");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MenuPrescriptions", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
	}

	@Then("^verify View All Prescriptions page$")
	public void verify_View_All_Prescriptions_page() throws Throwable {
	
       System.out.println("Mouse over to View All Prescriptions link");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_MenuPrescriptions", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.mouse_Hover(executionContext);
			
			String allPrescriptionXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wLnk_ViewAllPrescriptions", Browser);
			executionContext.setXpathDataPair(allPrescriptionXPath, "");
			OperationsDesktop.exist(executionContext);
			OperationsDesktop.click(executionContext);
			
			OperationsDesktop.wait_Page_Load(executionContext);
			
			String txtallPrescriptionXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wTxt_ViewAllPrescriptions", Browser);
			executionContext.setXpathDataPair(txtallPrescriptionXPath, "");

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 
		
	}

	@Then("^click All Prescriptions link and verify landing to Prescriptions page$")
	public void click_All_Prescriptions_link_and_verify_landing_to_Prescriptions_page() throws Throwable {
		
		
     System.out.println("Text All Prescriptions exist");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_Dashboard_Page",
					"wTxt_ViewAllPrescriptions", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext); 	
	}


	
	
	@Then("^user can logout and close the CMK browser$")
	public void user_can_logout_and_close_the_CMK_browser() throws Throwable {
	
		System.out.println("Log out");
		
		
		reportUtility.performInitialSetupForStep(executionContext);
		try {
		
		String signoutButtonXPath = ExecutionContext.getObjectLocator(
				DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage",
				"wLnk_LogOut", Browser);
		executionContext.setXpathDataPair(signoutButtonXPath, "");
		OperationsDesktop.wait_For_Object(executionContext);
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
			
	   }

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		   
       }
}
