package test.java.stepdefs.com.cvshealth.digital.library;

import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import cucumber.api.Scenario;

public class ReportUtility {
	
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: reportStepStatus <br>
	 * <b>DESCRIPTION: This method is used to report the activity execution status <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of WebDriver class
	 *  2.) Step Result
	 *  3.) Object of Senario class
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static void reportStepStatus(WebDriver driver, String stepResult, Scenario scenario) {
		try {
			scenario.write(stepResult);		
			byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.embed(screenshot, "image/png");
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: reportStepStatusWithoutScreenshot <br>
	 * <b>DESCRIPTION: This method is used to report the activity execution status without screenshot <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of ExecutionContext class
	 *  2.) expected step status
	 *  3.) actual step status
	 *  4.) Object of Senario class
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static void reportStepStatusWithoutScreenshot(ExecutionContext executionContext, String expectedResult, String actualResult, boolean stepStatus) {
		try {
			Log.writeToLogFile("Expected Result: "+expectedResult);
			Log.writeToLogFile("Actual Result: "+actualResult);
			Log.writeToLogFile("Status: "+stepStatus);
			
			executionContext.getAllOperationsStatusWithinAStep().add(stepStatus);
			executionContext.getScenario().write(actualResult);	
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: reportStepStatus <br>
	 * <b>DESCRIPTION: This method is used to report the activity execution status <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of ExecutionContext class
	 *  2.) expected step status
	 *  3.) actual step status
	 *  4.) Object of Senario class
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public static void reportStepStatus(ExecutionContext executionContext, String expectedResult, String actualResult, boolean stepStatus) {
		try {
			Log.writeToLogFile("Expected Result: " + expectedResult);
			Log.writeToLogFile("Actual Result: " + actualResult);
			Log.writeToLogFile("Status: " + stepStatus);

			executionContext.getAllOperationsStatusWithinAStep().add(stepStatus);
			executionContext.getScenario().write(actualResult);
			
			if ((!stepStatus) || PropertyFileLoader.getInstance().getSCREENSHOTS_EVERYWHERE().equalsIgnoreCase("YES")) {
				byte[] screenshot = ((TakesScreenshot) executionContext.getDriver()).getScreenshotAs(OutputType.BYTES);
				executionContext.getScenario().embed(screenshot, "image/png");
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: finalStatusSetupToExecuteForEveryStep <br>
	 * <b>DESCRIPTION: This method is used to update final status <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of ExecutionContext class
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public void finalStatusSetupToExecuteForEveryStep(ExecutionContext ec) {
		try {

			ArrayList<Boolean> operationStatusList = new ArrayList<>();
			operationStatusList = ec.getAllOperationsStatusWithinAStep();

			if (operationStatusList.contains(false)) {

				String dataKey = ec.getScenario().getName() + "_" + ec.getFeatureName();
				
				if (ExecutionContext.getScenario_Status_Map().containsKey(dataKey)) {

					String statusAlready = ExecutionContext.getScenario_Status_Map().get(dataKey);
					ExecutionContext.getScenario_Status_Map().put(dataKey, statusAlready + "|" + "FAIL");
				} else
					ExecutionContext.getScenario_Status_Map().put(dataKey, "FAIL");

				ec.getScenario().write("<b>" + "This step is failed" + "</b>");
				Assert.assertTrue(false);

			} else {

				ec.getScenario().write("<b>" + "This step is passed successfully" + "</b>");
				Assert.assertTrue(true);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			Log.writeToLogFile("Exception inside finalStatusSetupToExecuteForEveryStep");

		}
	}
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: performInitialSetupForStep <br>
	 * <b>DESCRIPTION: This method is used to set initial status <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of ExecutionContext class
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public void performInitialSetupForStep(ExecutionContext ec){
		try {
			ArrayList<Boolean>operationStatusList=new ArrayList<>();
			operationStatusList=ec.getAllOperationsStatusWithinAStep();
			operationStatusList.clear();
			ec.setAllOperationsStatusWithinAStep(operationStatusList);
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}

	}
	
	/**
	 * <p style="font-family:Arial;">
	 * <b>Method Name: setStatusOfOperationForStep <br>
	 * <b>DESCRIPTION: This method is used to set operation status <br>
	 * <br>
	 * Author: - ACOE Team <br>
	 * <br>
	 * Date Created: 05/03/2019 <br>
	 * <br>
	 * Revision History: <br>
	 * 1.0: Define method and added initial code <br>
	 * 
	 * @param 
	 * 	1.) Object of ExecutionContext class
	 *  2.) Step Status
	 * @return No Return Value
	 * @throws Exception
	 *             If any error occurs, reports the exception message and log the
	 *             full exception trace in log file </b>
	 *             </P>
	 * 
	 */
	public void setStatusOfOperationForStep(ExecutionContext ec, boolean flag){
		try { 
			ArrayList<Boolean>operationStatusList=new ArrayList<>();
			operationStatusList=ec.getAllOperationsStatusWithinAStep();
			operationStatusList.add(flag);
			ec.setAllOperationsStatusWithinAStep(operationStatusList);
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}		
	}

}
