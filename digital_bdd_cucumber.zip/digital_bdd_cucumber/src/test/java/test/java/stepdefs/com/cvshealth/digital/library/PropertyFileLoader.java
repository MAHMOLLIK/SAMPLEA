package test.java.stepdefs.com.cvshealth.digital.library;

import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;


public class PropertyFileLoader {

	//This object is used to store the specified properties
	private Properties properties = new Properties();
	
	//This is used to hold PropertyFileLoader object
	private static PropertyFileLoader objPropertyLoader = null;
	
	//This is used to hold current application URL
	private String URL;
	
	//This is used to hold the current environment
	private String ENVIRONMENT="";
	
	//This is used to store testing environment
	private String TestingEnvironment;
	
	//This is used to store Maria DB IP
	private String MARIA_DB_IP;
	
	//This is used to store Maria DB User
	private String MARIA_DB_USER;
	
	//This is used to store Maria DB User Password
	private String MARIA_DB_PASSWORD;
	
	//This is used to store Firefox browser path
	private String FIREFOX_BROWSER_PATH;
	
	//This is used to store Firefox driver path
	private String GECKO_DRIVER_PATH;
	
	//This is used to store IE driver path
	private String IE_DRIVER_PATH;
	
	//This is used to store chrome driver path
	private String CHROME_DRIVER_PATH;
	
	//This is used to store Edge driver path
	private String EDGE_DRIVER_PATH;
	
	//This is used to store Safari driver path
	private String SAFARI_DRIVER_PATH;
	
	//This is used to store data location (feature file / data base)
	private String FETCH_DATA_FROM_DB;
	
	//This is used to store current browser name
	private String currentBrowserName;
	
	//This is used to store current data base name
	private String currentDataBaseName;
	
	//This is used to store wait time specific for the environment
	private int WAIT_TIME_SEOCNDS;
	
	//This is used to store if screenshots are required or not
	private String SCREENSHOTS_EVERYWHERE;

	
	//Constructor to load property file
	private PropertyFileLoader() {
		try {
		loadConfigPropertiesFile();
		loadCommandLineProperties();
		loadEnvironmentPropertiesFile();
		
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	//Creating singlton object
	public static synchronized PropertyFileLoader getInstance() {
		if (objPropertyLoader == null)
			objPropertyLoader = new PropertyFileLoader();
		return objPropertyLoader;
	}

	/*
	 * =========================================================================================== 
	 * Function Name: loadConfigPropertiesFile
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to load the property from Config.properties file
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to load the property from Config.properties file
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No Parameters
	* @return No Return Value
	* @throws Exception  If any error occures, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/	
	public void loadConfigPropertiesFile() {
		FileInputStream fileInput = null;
		try {
			File file = new File("Config.properties");
			if(!file.exists()) {
				Log.writeToLogFile("Config property file '"+file.getAbsolutePath()+"' is not found");
				System.exit(0);
			}
			fileInput = new FileInputStream(file);
			properties.load(fileInput);
			
			
			//Set the property in required variable
			URL = getProperty("CVS_URL");
			if(URL==null || URL.equalsIgnoreCase("")) {
				URL = getProperty("URL");
			}
			
			//Set the environment
			ENVIRONMENT = getProperty("CVS_ENVIRONMENT");
			if(ENVIRONMENT==null || ENVIRONMENT.equalsIgnoreCase("")) {
				ENVIRONMENT = getProperty("ENVIRONMENT");
			}
			
			FETCH_DATA_FROM_DB = getProperty("FETCH_DATA_FROM_DB");
			MARIA_DB_IP = getProperty("MARIA_DB_IP");
			MARIA_DB_USER = getProperty("MARIA_DB_USER");
			MARIA_DB_PASSWORD = getProperty("MARIA_DB_PASSWORD");
			FIREFOX_BROWSER_PATH = getProperty("FIREFOX_BROWSER_PATH");
			GECKO_DRIVER_PATH = getProperty("GECKO_DRIVER_PATH");
			IE_DRIVER_PATH = getProperty("IE_DRIVER_PATH");
			CHROME_DRIVER_PATH = getProperty("CHROME_DRIVER_PATH");
			EDGE_DRIVER_PATH = getProperty("EDGE_DRIVER_PATH");
			SAFARI_DRIVER_PATH = getProperty("SAFARI_DRIVER_PATH");
			SCREENSHOTS_EVERYWHERE=getProperty("SCREENSHOTS_EVERYWHERE");

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			if (fileInput != null) {
				try {fileInput.close();} catch (IOException e) {e.printStackTrace();}
			}
		}

	}

	/*
	 * =========================================================================================== 
	 * Function Name: loadEnvironmentPropertiesFile
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to load the property from environment.Properties file
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to load the property from environment.Properties file
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No Parameters
	* @return No Return Value
	* @throws Exception  If any error occures, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/	
	public void loadEnvironmentPropertiesFile() {
		FileInputStream fileInput = null;
		try {
			File file = new File("src/test/resources/profiles/QA2/environment.Properties");
			if(!file.exists()) {
				Log.writeToLogFile("Environment property file '"+file.getAbsolutePath()+"' is not found");
			}
			fileInput = new FileInputStream(file);
			Properties environmentProperties=new Properties();
			environmentProperties.load(fileInput);
			
			String environmentURL=environmentProperties.getProperty("URL");
			String environmentCVSURL=environmentProperties.getProperty("CVS_URL");
			boolean foundInEnvironmentFile=false;
			String finalURL="";
			if(environmentCVSURL==null || environmentCVSURL.equalsIgnoreCase("")) {
				if(environmentURL==null || environmentURL.equalsIgnoreCase("")) {
					
				}else {
					finalURL=environmentURL;
					foundInEnvironmentFile=true;
				}
			}else {				
				finalURL=environmentCVSURL;
				foundInEnvironmentFile=true;
			}
			if(foundInEnvironmentFile) {
				URL=finalURL;
			}else {
				
			}		
			properties.setProperty("URL", URL);
			properties.setProperty("CVS_URL", URL); 
			
			String environment=environmentProperties.getProperty("ENVIRONMENT");
			String environmentCVS=environmentProperties.getProperty("CVS_ENVIRONMENT");
			foundInEnvironmentFile=false;
			String finalEnvironment="";
			if(environmentCVS==null || environmentCVS.equalsIgnoreCase("")) {
				if(environment==null || environment.equalsIgnoreCase("")) {
					
				}else {
					finalEnvironment=environment;
					foundInEnvironmentFile=true;
				}
			}else {				
				finalEnvironment=environmentCVS;
				foundInEnvironmentFile=true;
			}
			if(foundInEnvironmentFile) {
				ENVIRONMENT=finalEnvironment;
			}else {
				
			}
			properties.setProperty("CVS_ENVIRONMENT", ENVIRONMENT);
			properties.setProperty("ENVIRONMENT", ENVIRONMENT);
			
			Log.writeToLogFile("URL: "+URL);
			Log.writeToLogFile("URL: "+ENVIRONMENT);
			getProperty("CVS_URL");
			getProperty("URL");
			getProperty("CVS_ENVIRONMENT");
			getProperty("ENVIRONMENT");
			
			//monitoring wait time in try catch as if it throws exception it will be initialized as zero and next enumeration loop will also execute.
			
			try{
			WAIT_TIME_SEOCNDS=(Integer.parseInt(environmentProperties.getProperty("WAIT_TIME_SECONDS")));
			}catch (Exception e) {
				WAIT_TIME_SEOCNDS=0;
				ExceptionHandler.handleException(e);
			}
			
			//Store environment properties in to properties object
			@SuppressWarnings("rawtypes")
			Enumeration e = environmentProperties.propertyNames();
		    while (e.hasMoreElements()) {
		      String key = (String) e.nextElement();
		      properties.setProperty(key, environmentProperties.getProperty(key));
		    }

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			if (fileInput != null) {
				try {fileInput.close();} catch (IOException e) {e.printStackTrace();}
			}
		}

	}	

	/*
	 * =========================================================================================== 
	 * Function Name: printProperties
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to print the properties
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to print the properties
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No Parameters
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/
	public void printProperties(){
		try {
		if(properties==null) {
			Log.writeToLogFile("Properites not found");
			return ;
		}
		@SuppressWarnings("rawtypes")
		Enumeration e = properties.propertyNames();
	    while (e.hasMoreElements()) {
	      String key = (String) e.nextElement();
	      Log.writeToLogFile("Value of peroperty "+key+" is: "+properties.getProperty(key));
	    }
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	
	/*
	 * =========================================================================================== 
	 * Function Name: loadCommandLineProperties
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to load the command line properties
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to load the command line properties
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No Parameters
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/	
	public void loadCommandLineProperties() {
		// TODO Auto-generated method stub
		try {
			currentBrowserName = System.getProperty("Browser");
			currentDataBaseName = System.getProperty("DB");

			properties.setProperty("Current_Browser", currentBrowserName);
			properties.setProperty("Current_Data_Base", currentDataBaseName);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}


	/*
	 * =========================================================================================== 
	 * Function Name: setProperty
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to set property with specified value
	 * Parameter: 
	 * 		1. String - property name
	 * 		2. String property value
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to set property with specified value
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	 * @Parameter: 
	 * 		1. String - property name
	 * 		2. String property value
	* @return No Return Value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/	
	public void setProperty(String propertyName, String propertyValue) {
		try {
			properties.setProperty(propertyName, propertyValue);
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	
	/*
	 * =========================================================================================== 
	 * Function Name: getProperty
	 * CREATED BY: ACOE Team
	 * CREATED DATE: 05/03/2019
	 * DESCRIPTION: This method is used to get specified property value
	 * Parameter: None
	 * RETURNS: Nothing
	 * COMMENTS: 
	 * Modification Log: 
	 * Revision: 1.0
	 * Date: 05/03/2019
	 * Comment: Implemented method with initial requirement
	 *  
	 * ===========================================================================================
	 */
	/** 
	* <p style="font-family:Arial;">
	* <b>DESCRIPTION: This method is used to get specified property value
	* <br><br>
	* Author: - ACOE Team
	* <br><br>
	* Date Created: 05/03/2019
	* <br><br>Revision History: 
	* <br>1.0: Define method and added initial code
	* <br>
	* @param  No Parameters
	* @return String - Property value
	* @throws Exception  If any error occurs, reports the exception message and log the full exception trace in log file
	* </b></P> 
	* 
	*/	
	public String getProperty(String propertyName) {
		String returnData="";
		try {
			returnData=properties.getProperty(propertyName);
			Log.writeToLogFile("Value of property '"+propertyName+"' is '"+returnData+"'");
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		return returnData;
	}
	
	
	
	
	
	
	
	/**
	 * Setter and getter methods
	 * 
	 */
	public Properties getProp() {
		return properties;
	}

	public String getURL() {
		return URL;
	}

	public String getMARIA_DB_IP() {
		return MARIA_DB_IP;
	}

	public String getMARIA_DB_USER() {
		return MARIA_DB_USER;
	}

	public String getMARIA_DB_PASSWORD() {
		return MARIA_DB_PASSWORD;
	}

	public String getFIREFOX_BROWSER_PATH() {
		return FIREFOX_BROWSER_PATH;
	}

	public String getGECKO_DRIVER_PATH() {
		return GECKO_DRIVER_PATH;
	}

	public String getIE_DRIVER_PATH() {
		return IE_DRIVER_PATH;
	}

	public String getCHROME_DRIVER_PATH() {
		return CHROME_DRIVER_PATH;
	}

	public String getEDGE_DRIVER_PATH() {
		return EDGE_DRIVER_PATH;
	}

	public String getSAFARI_DRIVER_PATH() {
		return SAFARI_DRIVER_PATH;
	}

	public String getFETCH_DATA_FROM_DB() {
		return FETCH_DATA_FROM_DB;
	}

	public String getBrowser() {
		return currentBrowserName;
	}

	public String getDB() {
		return currentDataBaseName;
	}

	public String getTestingEnvironment() {
		return TestingEnvironment;
	}

	public void setTestingEnvironment(String testingEnvironment) {
		TestingEnvironment = testingEnvironment;
	}

	public String getENVIRONMENT() {
		return ENVIRONMENT;
	}

	public void setENVIRONMENT(String eNVIRONMENT) {
		ENVIRONMENT = eNVIRONMENT;
	}

	public int getWAIT_TIME_SEOCNDS() {
		return WAIT_TIME_SEOCNDS;
	}

	public void setWAIT_TIME_SEOCNDS(int wAIT_TIME_SEOCNDS) {
		WAIT_TIME_SEOCNDS = wAIT_TIME_SEOCNDS;
	}

	public String getSCREENSHOTS_EVERYWHERE() {
		return SCREENSHOTS_EVERYWHERE;
	}

	public void setSCREENSHOTS_EVERYWHERE(String sCREENSHOTS_EVERYWHERE) {
		SCREENSHOTS_EVERYWHERE = sCREENSHOTS_EVERYWHERE;
	}

}
