package test.java.stepdefs.com.cvshealth.digital.orm.orderstatusaurus;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;

public class ShipConsent extends AbstractStepDefinition {
	
@Given("^user switch to shipconsent page$")
public void user_switch_to_shipconsent_page(){
    // Write code here that turns the phrase above into concrete actions
	
	try{
		String shipConsentTitle = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wTxt_ShipConsentTitle", Browser);
		String iframeName=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","WElt_iFrame",Browser);
		//execute generic method inside the assert statement to terminate in case of failure
		executionContext.setXpathDataPair("", "https://sit1v8ptlint.caremark.com/wps/myportal/SHIP_CONSENT");
		Assert.assertTrue(OperationsDesktop.navigateURL(executionContext));
		
		executionContext.setXpathDataPair(iframeName, "");
		OperationsDesktop.switch_To_Frame_By_Object(executionContext);
		
		executionContext.setXpathDataPair(shipConsentTitle, "");
		OperationsDesktop.wait_For_Object(executionContext);
    
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);		
	}    
	}

@Then("^user sees title and shipconsent NoRx copy$")
public void user_sees_title_and_shipment_NoRx_copy(){
    // Write code here that turns the phrase above into concrete actions
	
	try{
		//Retrieve required xpath from DB
		
		String shipConsentTitle = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wTxt_ShipConsentTitle", Browser);
		String shipConsentMsg1 = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wTxt_ShipConsentNoRxLine1", Browser);
		String shipConsentMsg2 = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wTxt_ShipConsentNoRxLine2", Browser);
		
		//Verify if title and copy is displayed for a member with no rx to consent

		OperationsDesktop.exist(executionContext);	
		OperationsDesktop.exist(executionContext);
		OperationsDesktop.exist(executionContext);
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);		
	}    
	}

 

/***********************************************************************************************************************
 * #4 ORDER-245
 * 
 ************************************************************************************************************************/

@Given("^user launched \"([^\"]*)\"$")
public void user_launched(String ship_consent_url) {
	reportUtility.performInitialSetupForStep(executionContext);
	try {
					
				
		executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getProperty(ship_consent_url));
		
		//in this example only URL is expected
		//execute generic method inside the assert statement to terminate in case of failure
		Assert.assertTrue("URL"+PropertyFileLoader.getInstance().getProperty(ship_consent_url)+ " navigated successfully",OperationsDesktop.navigateURL(executionContext));
		Thread.sleep(20000);
		
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
		
		
	@Given("^logged in with valid credentials$")	
	public void logged_in_with_valid_credentials(DataTable objDataTable) {
	
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			//Get required data 
			String userName=executionContext.getExecutionData(objDataTable, "username");
			String password=executionContext.getExecutionData(objDataTable, "password");		
		
			
		//set xpath for Username object and input
		String userNameXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wEdt_Username",Browser);			
		executionContext.setXpathDataPair(userNameXPath, userName);
		
		//both the operations can be invoked sequentially as both require same xPath and data which has been set already
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.input(executionContext);	
		
		
		//click in Password text box
		String userPasswordtextxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wEdt_PasswordPlaceholder",Browser);
		executionContext.setXpathDataPair(userPasswordtextxPath, "");
		OperationsDesktop.click(executionContext);
		
		//set xpath for Password object and input
		String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wEdt_Password",Browser);
		executionContext.setXpathDataPair(userPasswordxPath, password);
		OperationsDesktop.input(executionContext);
		
		//click SignIn
		String signInButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wBtn_SignIn",Browser);
		executionContext.setXpathDataPair(signInButtonXPath, "");
		OperationsDesktop.click(executionContext);
		
		
		//wait_For_Object
		String signoutButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_LoggedInPage","wLnk_LogOut",Browser);
		executionContext.setXpathDataPair(signoutButtonXPath, "");
		OperationsDesktop.wait_For_Object(executionContext);
		
	
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
	
	
	@Given("^On Hold Prescription Medication screen is loaded in iframe component$")
	public void On_Hold_Prescription_Medication_screen_is_loaded_in_iframe_component () {
		
		try{
			
			String iframeName=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wElt_iFrame",Browser);
			executionContext.setXpathDataPair(iframeName, "");
			//OperationsDesktop.wait_For_Object(executionContext);
			//OperationsDesktop.wait(executionContext);
		    OperationsDesktop.switch_To_Frame_By_Object(executionContext);
		    Thread.sleep(20000);
		    
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				reportUtility.setStatusOfOperationForStep(executionContext, false);

			}
			reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		}
		

	

@Then ("^verify no ship consent message is displayed to the user$")
public void verify_no_ship_consent_message_is_displayed_to_the_user(DataTable objDataTable) {	
		
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		//Parse data form local / Data Base
		String NoConsent_message =executionContext.getExecutionData(objDataTable,"NoConsent_message");

		//Get activity object / data
		String wMsg_NoConsentmessage = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wMsg_NoConsentmessage", Browser);
		executionContext.setXpathDataPair(wMsg_NoConsentmessage, NoConsent_message);
		OperationsDesktop.validate_Object_Text(executionContext);
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
	
		


/***********************************************************************************************************************
 * #5 ORDER-245
 * 
 ************************************************************************************************************************/
@Given("Confirm Your Identity screen is loaded in iframe component$")
public void Confirm_Your_Identity_screen_is_loaded_in_iframe_component () {
	
	try{
		
		String iframeName=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentPage","wElt_iFrame",Browser);
		executionContext.setXpathDataPair(iframeName, "");
		//OperationsDesktop.wait_For_Object(executionContext);
		//OperationsDesktop.wait(executionContext);
	    OperationsDesktop.switch_To_Frame_By_Object(executionContext);
	    Thread.sleep(20000);
	    
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	


@Given ("^authenticate with date of birth$")
public void authenticate_with_date_of_birth(DataTable objDataTable) {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {

		//Enter DOB
		
		String DOB=executionContext.getExecutionData(objDataTable, "Date_of_Birth");
		
		String DOBXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wEdt_DOB",Browser);			
		executionContext.setXpathDataPair (DOBXPath, DOB);
		OperationsDesktop.click(executionContext);
		OperationsDesktop.input(executionContext);
		
		/*String DOB=executionContext.getExecutionData(objDataTable, "Date_of_Birth");
		String DOBXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wEdt_DOB",Browser);			
		executionContext.setXpathDataPair (DOBXPath, DOB);
		OperationsDesktop.input(executionContext);*/
	
		//click Continue
		String ContinueButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentLoginPage","wBtn_Continue",Browser);
		executionContext.setXpathDataPair(ContinueButtonXPath, "");
		OperationsDesktop.click(executionContext);
		Thread.sleep(30000);
	
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}
	

@Then ("^verify no ship consent message is displayed$")
public void verify_no_ship_consent_message_is_displayed (DataTable objDataTable) {
	
	reportUtility.performInitialSetupForStep(executionContext);
	try {
		
		//Parse data form local / Data Base
		String NoConsent_message =executionContext.getExecutionData(objDataTable,"NoConsent_message");

		//Get activity object / data
		String wMsg_NoConsentmessage = ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CMK_ShipConsentDOBPage","wMsg_NoConsentmessage", Browser);
		executionContext.setXpathDataPair(wMsg_NoConsentmessage, NoConsent_message);
		OperationsDesktop.validate_Object_Text(executionContext);
		
	} catch (Exception e) {
		ExceptionHandler.handleException(e);
		reportUtility.setStatusOfOperationForStep(executionContext, false);

	}
	reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
}

}


