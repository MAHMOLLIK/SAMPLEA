package test.java.stepdefs.com.cvshealth.digital.cat.clinicaltools;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.Log;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;
import test.java.stepdefs.com.cvshealth.digital.library.ReportUtility;

public class RoutineMedications extends AbstractStepDefinition {

	@Given("^CVS dot com Script Path user logged into ICE Pharmacy using valid credentials \"([^\"]*)\", \"([^\"]*)\"$")

	public void cvs_dot_com_script_path_user_logged_into_ice_pharmacy_using_valid_credentials(String userName,
			String password) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get required data from data base
			userName = executionContext.getExecutionData("username", userName);
			password = executionContext.getExecutionData("password", password);

			/*
			 * for each method call, user should set xpath-data pair and then call method
			 * pass empty string respectively when xpath/data is not required to call the
			 * method
			 */

			// navigateUrl - set url to execution context
			// set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());

			// in this example only URL is expected
			// execute generic method inside the assert statement to terminate in case of
			// failure
			Assert.assertTrue("URL " + PropertyFileLoader.getInstance().getURL() + " navigated successfully",
					OperationsDesktop.navigateURL(executionContext));

			// read xpath for email address edit box object
			String userNameXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wEdt_EmailAddress", Browser);

			// set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(userNameXPath, "");
			// set current execution context and advance to the next working element
			OperationsDesktop.wait_For_Object(executionContext);

			executionContext.setXpathDataPair(userNameXPath, userName);
			// set current xpath and data for input method
			OperationsDesktop.input(executionContext);

			// set current xpath and current data for input function
			String userPasswordxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			// click
			String signInButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wBtn_SignIn",
					Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);

			// wait_For_Object
			String signoutButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage",
					"wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^User clicks on Prescription schedule link$")
	public void user_clicks_on_prescription_schedule_link() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Static Wait to wait for few mins before checking on the prescription schedule
			// link
			executionContext.setCurrentElementData("6000");
			OperationsDesktop.wait(executionContext);

			Actions act = new Actions (executionContext.getDriver());

			String myPrescriptions = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wElt_MyPrescriptions", Browser);
			executionContext.setXpathDataPair(myPrescriptions, "");
			OperationsDesktop.mouse_Hover(executionContext);

			// Click prescription Schedule link
			String prescriptionScheduleLink = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wLnk_PrescriptionSchedule", Browser);		

			WebElement ePrescriptionLink = executionContext.getDriver().findElement(By.xpath(prescriptionScheduleLink));
			act.moveToElement(ePrescriptionLink);
			act.build().perform();

			executionContext.setXpathDataPair(prescriptionScheduleLink, "");
			OperationsDesktop.click(executionContext);

			executionContext.setCurrentElementData("6000");
			OperationsDesktop.wait(executionContext);

			// Wait until Prescription Schedule Page loads
			String prescriptionScheduleHeader = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PrescriptionSchedule", Browser);
			executionContext.setXpathDataPair(prescriptionScheduleHeader, "");


			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^user is landed on prescription schedule page$")
	public void user_is_landed_on_prescription_schedule_page() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Static Wait
			executionContext.setCurrentElementData("2000");
			OperationsDesktop.wait(executionContext);

			// Verify user is on prescription schedule page or not
			String prescriptionScheduleHeader = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PrescriptionSchedule", Browser);
			executionContext.setXpathDataPair(prescriptionScheduleHeader, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Given("^User with \"([^\"]*)\", \"([^\"]*)\" is in prescription schedule page$")
	public void user_is_in_prescription_schedule_page(String userName, String password) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// user sign in
			cvs_dot_com_script_path_user_logged_into_ice_pharmacy_using_valid_credentials(userName, password);
			// user navigate to prescription schedule page
			user_clicks_on_prescription_schedule_link();

			String pageLoadOverLay = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PageLoadOverLay", Browser);
			WebDriverWait myWait = new WebDriverWait (executionContext.getDriver(),30);
			myWait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(pageLoadOverLay)));


		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^User switch to \"([^\"]*)\" page$")
	public void user_switch_to_caregivee_page(String caregivee) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get required data from data base
			caregivee = executionContext.getExecutionData("caregivee", caregivee);
			String careGiveeListPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wLnk_CareGivees", Browser);

			// Get the caregivee elements in a list
			List<WebElement> eCareGiveeList = executionContext.getDriver().findElements(By.xpath(careGiveeListPath));


			if(caregivee==null) {

				Log.writeToLogFile(
						"caregivee info is not provided in the feature file or data table");
				String expectedResult = "Care Givee Name is not given in the Data table, hence not searching for caregivee tab";
				String actualResult = "Care Givee Name is not given in the Data table, hence not searching for caregivee tab";
				boolean status = true;
				ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
			}
			else {
				// Check if the size of the list is greater than Zero
				if (eCareGiveeList.size() > 0) {

					boolean bCareGiveeFound = false;
					// Looping through the care givee list to switch to a cage givee mentioned in
					// the data file or in Feature file
					for (WebElement el : eCareGiveeList) {

						if (el.getText().equalsIgnoreCase(caregivee) || el.getText().contains(caregivee)) {

							el.click();
							bCareGiveeFound = true;
							// Static Wait
							executionContext.setCurrentElementData("10000");
							OperationsDesktop.wait(executionContext);

							String careGiveeNamePath = ExecutionContext.getObjectLocator(
									DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
									"PrescriptionSchedule_Page", "wElt_PrescriptionSchedule_CareGivee", Browser);
							careGiveeNamePath = careGiveeNamePath.replace("REPLACE###", caregivee);
							executionContext.setXpathDataPair(careGiveeNamePath, "");
							OperationsDesktop.exist(executionContext);
							break;

						}

					} // End Of For

					if (!bCareGiveeFound) {

						Log.writeToLogFile(
								"No Caregivee or GareGiver with given name as " + caregivee + " is found in the page");
						// Pasting Screen shot in the report for user verification
						if (PropertyFileLoader.getInstance().getSCREENSHOTS_EVERYWHERE().equalsIgnoreCase("YES")) {
							byte[] screenshot = ((TakesScreenshot) executionContext.getDriver())
									.getScreenshotAs(OutputType.BYTES);
							executionContext.getScenario().embed(screenshot, "image/png");
						}
					}

				} else {

					Log.writeToLogFile(
							"No Caregivee or GareGiver tab is found in the page, may be page is not loaded properly");
					// Pasting Screen shot in the report for user verification
					if (PropertyFileLoader.getInstance().getSCREENSHOTS_EVERYWHERE().equalsIgnoreCase("YES")) {
						byte[] screenshot = ((TakesScreenshot) executionContext.getDriver())
								.getScreenshotAs(OutputType.BYTES);
						executionContext.getScenario().embed(screenshot, "image/png");
					}
				} // End Of If

			}

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^User is able to see prescription schedule page for caregivee$")
	public void user_is_able_to_see_presription_schedule_page_for_caregivee() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			user_is_landed_on_prescription_schedule_page();

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^User is able to see all basic informations such as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_is_able_to_see_all_basic_informations(String caregivee, String lastname, String dob,
			String createddateformat) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			caregivee = executionContext.getExecutionData("caregivee", caregivee);
			dob = executionContext.getExecutionData("dob", dob);
			lastname = executionContext.getExecutionData("lastname", lastname);
			createddateformat = executionContext.getExecutionData("createddateformat", createddateformat);

			// Retrieve all the xpath needed for validation
			String downloadPdfPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_DowloadPDF", Browser);
			String userProfileNamePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_UserProfileName", Browser);
			String userDobPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PatientDOB", Browser);
			String createdDatePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_CreatedOnDate", Browser);

			// verify Down load PDF link Existence
			executionContext.setXpathDataPair(downloadPdfPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify User Full Name
			userProfileNamePath = userProfileNamePath.replace("REPLACEFIRSTNAME", caregivee);
			userProfileNamePath = userProfileNamePath.replace("REPLACELASTNAME", lastname);
			executionContext.setXpathDataPair(userProfileNamePath, "");
			OperationsDesktop.exist(executionContext);

			// Verify DOB
			executionContext.setXpathDataPair(userDobPath, "");
			executionContext.setCurrentElementData(dob);
			OperationsDesktop.validate_Object_Text(executionContext);

			// Verify created Date
			executionContext.setXpathDataPair(createdDatePath, "");
			String sCreatedDate = OperationsDesktop.retrieveText(executionContext);

			String[] elements = sCreatedDate.split(" ");
			DateTimeFormatter f = DateTimeFormatter.ofPattern(createddateformat.trim());
			// DateTimeFormatter f = DateTimeFormatter.ofPattern(createddateformat) ;
			List<LocalDate> dates = new ArrayList<>();
			for (String element : elements) {
				try {
					LocalDate ld = LocalDate.parse(element, f);
					dates.add(ld);
				} catch (DateTimeParseException e) {
					// Ignore the exception. Move on to next element.
				}
			}
			System.out.println("Created Date After Retrieval: " + dates);

			// Getting the current date
			LocalDate currDate = LocalDate.now();

			if (dates.get(0).equals(currDate)) {

				String expectedResult = "Created On Date Matches the System current date";
				String actualResult = "Created On Date Matches the System current date";
				boolean status = true;
				ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);

			} else {

				String expectedResult = "Created On Date Matches the System current date";
				String actualResult = "Created On Date does not Match with the System current date";
				boolean status = false;
				ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);

			}

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^User is able to see all basic components of Routine medications table$")
	public void user_is_able_to_see_all_basic_componenets_of_routine_medications_table() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Retrieve all the xpath needed for validation
			String directionForUsePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_Medication_DirectionForUse", Browser);
			String refillInfoPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RefillInfo", Browser);
			String sixMonthPickUpHistoryPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_6MonthPickUpHistory", Browser);
			String morningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MorningSlot", Browser);
			String middaySlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_MiddaySlot", Browser);
			String eveningSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_EveningSlot", Browser);
			String bedtimeSlotPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_BedtimeSlot", Browser);

			// Verify Medications or Directions for use column
			executionContext.setXpathDataPair(directionForUsePath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Refill Information column
			executionContext.setXpathDataPair(refillInfoPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify 6 Month Pick Up Information column
			executionContext.setXpathDataPair(sixMonthPickUpHistoryPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Morning Slot column
			executionContext.setXpathDataPair(morningSlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Middday Slot column
			executionContext.setXpathDataPair(middaySlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Evening Slot column
			executionContext.setXpathDataPair(eveningSlotPath, "");
			OperationsDesktop.exist(executionContext);

			// Verify Bedtime Slot column
			executionContext.setXpathDataPair(bedtimeSlotPath, "");
			OperationsDesktop.exist(executionContext);

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^User is able to see slotting \"([^\"]*)\" for medication \"([^\"]*)\"$")
	public void user_is_able_to_see_slotting_for_medication(String slotting, String medication) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file
			slotting = executionContext.getExecutionData("slotting", slotting);
			medication = executionContext.getExecutionData("medication", medication);

			// Retrieve all the xpath needed for validation
			String rxMorningSlottingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxMorningSlotting", Browser);
			String rxMiddaySlottingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxMiddaySlotting", Browser);
			String rxEveningSlottingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxEveningSlotting", Browser);
			String rxBedtimeSlottingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxBedtimeSlotting", Browser);
			String rxNoSlottingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_NoSlotMessageForRx", Browser);



			switch (slotting.toUpperCase()) {

			case "MORNING":
				rxMorningSlottingPath = rxMorningSlottingPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxMorningSlottingPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				break;
			case "MIDDAY":
				rxMiddaySlottingPath = rxMiddaySlottingPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxMiddaySlottingPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				break;
			case "EVENING":
				rxEveningSlottingPath = rxEveningSlottingPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxEveningSlottingPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				break;
			case "BEDTIME":
				rxBedtimeSlottingPath = rxBedtimeSlottingPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxBedtimeSlottingPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				break;
			case "NOSLOTTING":
				rxNoSlottingPath = rxNoSlottingPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxNoSlottingPath, "");
				OperationsDesktop.wait_For_Object(executionContext);
				OperationsDesktop.exist(executionContext);
				break;

			}

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@Then("^User is able to see \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for medication \"([^\"]*)\"$")
	public void user_is_able_to_see_rxinformation_for_medication(String rxnumber, String refillsremaining,
			String rxstore, String telephonenumber, String prescribername, String medication) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file
			rxnumber = executionContext.getExecutionData("rxnumber", rxnumber);
			refillsremaining = executionContext.getExecutionData("refillsremaining", refillsremaining);
			rxstore = executionContext.getExecutionData("rxstore", rxstore);
			telephonenumber = executionContext.getExecutionData("telephonenumber", telephonenumber);
			prescribername = executionContext.getExecutionData("prescribername", prescribername);
			medication = executionContext.getExecutionData("medication", medication);

			// Retrieve all the xpath needed for validation
			String rxNumberPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxNumber", Browser);
			String rxRefillRemainingPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxRefillsRemaining", Browser);
			String rxStorePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxStore", Browser);
			String rxTelephonePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_StoreTelePhoneNumber", Browser);
			String rxPrescriberNamePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PrescriberName", Browser);


			//Validate the Rx Number
			rxNumberPath = rxNumberPath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxNumberPath, rxnumber);
			OperationsDesktop.validate_Object_Text(executionContext);

			//validate refills remaining
			rxRefillRemainingPath = rxRefillRemainingPath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxRefillRemainingPath, refillsremaining);
			OperationsDesktop.validate_Object_Text(executionContext);

			//validate rxStore 
			rxStorePath = rxStorePath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxStorePath, rxstore);
			OperationsDesktop.validate_Object_Text(executionContext);

			//validate rxTelePhone
			rxTelephonePath = rxTelephonePath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxTelephonePath, telephonenumber);
			OperationsDesktop.validate_Object_Text(executionContext);

			//validate Prescriber name
			rxPrescriberNamePath = rxPrescriberNamePath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxPrescriberNamePath, prescribername);
			OperationsDesktop.validate_Object_Text(executionContext);




		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


	@Then("^User is able to see correct values for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for medication \"([^\"]*)\"$")
	public void user_is_able_to_see_correct_values_for_sixmonthpickuphistory_for_medication (String rxpickuphistory , String rxpickbydateleadtext ,String rxpickupbydate , String potentialmisseddays, String medication) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file			
			rxpickuphistory = executionContext.getExecutionData("rxpickuphistory", rxpickuphistory);
			rxpickbydateleadtext = executionContext.getExecutionData("rxpickbydateleadtext", rxpickbydateleadtext);
			rxpickupbydate = executionContext.getExecutionData("rxpickupbydate", rxpickupbydate);
			medication = executionContext.getExecutionData("medication", medication);
			potentialmisseddays = executionContext.getExecutionData("potentialmisseddays", potentialmisseddays);

			// Retrieve all the xpath needed for validation
			String rxPickupHistoryPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxPickupHistoryInfo", Browser);
			String rxPickByDateLeadTextPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PickUpByDateLeadText", Browser);
			String rxPickupByDatePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RxPickUpByDate", Browser);
			String potentialmisseddaysPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_PotentialDaysMissed", Browser);

			JavascriptExecutor js = (JavascriptExecutor) executionContext.getDriver();
			// This  will scroll down the page by  1000 pixel vertical		
			js.executeScript("window.scrollBy(0,1000)");


			//Validate the RxPickupHistory

			if(!(rxpickuphistory.equalsIgnoreCase(""))) {

				rxPickupHistoryPath = rxPickupHistoryPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxPickupHistoryPath, rxpickuphistory);
				OperationsDesktop.validate_Object_Text(executionContext);

			}else {

				rxPickupHistoryPath = rxPickupHistoryPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxPickupHistoryPath, rxpickuphistory);
				OperationsDesktop.validate_Object_Text_Is_Blank(executionContext);
			}
			
			
			//validate leat text for pick up by date
			
			if(!(rxpickbydateleadtext.equalsIgnoreCase(""))) {
				rxPickByDateLeadTextPath = rxPickByDateLeadTextPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(rxPickByDateLeadTextPath, rxpickbydateleadtext);
				OperationsDesktop.validate_Object_Text(executionContext);
			}

			//validate refills remaining
			
			if(!(rxpickupbydate.equalsIgnoreCase(""))) {
			rxPickupByDatePath = rxPickupByDatePath.replace("REPLACERXNAME", medication);
			executionContext.setXpathDataPair(rxPickupByDatePath, rxpickupbydate);
			OperationsDesktop.validate_Object_Text(executionContext);
			}
			
			
			//validate potential missed days			
			if(!(potentialmisseddays.equalsIgnoreCase(""))) {
				potentialmisseddaysPath = potentialmisseddaysPath.replace("REPLACERXNAME", medication);
				executionContext.setXpathDataPair(potentialmisseddaysPath, potentialmisseddays);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				if(rxPickupHistoryPath.equalsIgnoreCase("")) {
					
					potentialmisseddaysPath = potentialmisseddaysPath.replace("REPLACERXNAME", medication);
					executionContext.setXpathDataPair(potentialmisseddaysPath, potentialmisseddays);
					OperationsDesktop.not_Exist(executionContext);
				}
			}

		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


	@Given("^Control group user is in Pharmacy login page$")
	public void control_group_user_is_in_pharmacy_login_page() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// navigateUrl - set url to execution context
			// set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());

			// in this example only URL is expected
			// execute generic method inside the assert statement to terminate in case of
			// failure
			Assert.assertTrue("URL " + PropertyFileLoader.getInstance().getURL() + " navigated successfully",
					OperationsDesktop.navigateURL(executionContext));

		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


	@When("^User logs into the application using the credentials \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_logs_into_the_application_using_the_credentials(String userName , String password) {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get required data from data base
			userName = executionContext.getExecutionData("username", userName);
			password = executionContext.getExecutionData("password", password);


			// read xpath for email address edit box object
			String userNameXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wEdt_EmailAddress", Browser);

			// set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(userNameXPath, "");
			// set current execution context and advance to the next working element
			OperationsDesktop.wait_For_Object(executionContext);

			executionContext.setXpathDataPair(userNameXPath, userName);
			// set current xpath and data for input method
			OperationsDesktop.input(executionContext);

			// set current xpath and current data for input function
			String userPasswordxPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			// click
			String signInButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wBtn_SignIn",
					Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);

			// wait_For_Object
			String signoutButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage",
					"wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


	@Then("^User is not able to see precsription schedule entry points$")
	public void user_is_not_able_to_see_prescription_schedule_entry_points () {

		reportUtility.performInitialSetupForStep(executionContext);

		try {


			// Static Wait to wait for few mins before checking on the prescription schedule
			// link
			executionContext.setCurrentElementData("6000");
			OperationsDesktop.wait(executionContext);

			Actions act = new Actions (executionContext.getDriver());
			String myPrescriptions = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wElt_MyPrescriptions", Browser);
			executionContext.setXpathDataPair(myPrescriptions, "");
			OperationsDesktop.mouse_Hover(executionContext);

			// read xpath for prescription schedule fly down object
			String prescriptionScheduleFlyDownXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wLnk_PrescriptionSchedule_FlyDown", Browser);

			// set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(prescriptionScheduleFlyDownXPath, "");
			OperationsDesktop.not_Exist(executionContext);


			JavascriptExecutor js = (JavascriptExecutor) executionContext.getDriver();
			// This  will scroll down the page by  1000 pixel vertical		
			js.executeScript("window.scrollBy(0,1000)");


			// read xpath for prescription Schedule link
			String prescriptionScheduleLink = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wLnk_PrescriptionSchedule", Browser);
			executionContext.setXpathDataPair(prescriptionScheduleLink, "");
			OperationsDesktop.not_Exist(executionContext);



		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}


	@And("^User clicks on Prescription schedule link as guest user$")
	public void user_clicks_on_prescription_schedule_link_as_guest_user() {

		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Static Wait to wait for few mins before checking on the prescription schedule
			// link
			executionContext.setCurrentElementData("6000");
			OperationsDesktop.wait(executionContext);

			Actions act = new Actions (executionContext.getDriver());
			String myPrescriptions = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
					"wElt_MyPrescriptions", Browser);
			executionContext.setXpathDataPair(myPrescriptions, "");
			OperationsDesktop.mouse_Hover(executionContext);

			// Click prescription Schedule link
			String prescriptionScheduleLink = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wLnk_PrescriptionSchedule_FlyDown", Browser);
			executionContext.setXpathDataPair(prescriptionScheduleLink, "");
			OperationsDesktop.click(executionContext);

			executionContext.setCurrentElementData("6000");
			OperationsDesktop.wait(executionContext);			

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}


	@Then("^User is able to see correct values for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for \"([^\"]*)\" adherence value$")
	public void user_is_able_to_see_correct_values_for_adherence_spotlight (String spotlighttitle , String spotlighttext1 , String spotlighttext2 , String refilltitle , String refilltext , String autorefilltext , String adherence ) {


		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file			
			spotlighttitle = executionContext.getExecutionData("spotlighttitle", spotlighttitle);
			spotlighttext1 = executionContext.getExecutionData("spotlighttext1", spotlighttext1);
			spotlighttext2 = executionContext.getExecutionData("spotlighttext2", spotlighttext2);
			refilltitle = executionContext.getExecutionData("refilltitle", refilltitle);
			refilltext = executionContext.getExecutionData("refilltext", refilltext);
			autorefilltext = executionContext.getExecutionData("autorefilltext", autorefilltext);
			adherence = executionContext.getExecutionData("adherence", adherence);

			// Retrieve all the xpath needed for validation
			String spotlighttitlePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_SpotLightTitle", Browser);
			String spotlighttext1Path = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_SpotLightText1", Browser);
			String spotlighttext2Path = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_SpotLightText2", Browser);
			String refilltitlePath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RefillTitle", Browser);
			String refilltextPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_RefillText", Browser);
			String autorefilltextPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wLnk_StartAutomaticRefills", Browser);
			
			//Validate Spotlight Title
			if(!spotlighttitle.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(spotlighttitlePath, "");
				executionContext.setCurrentElementData(spotlighttitle);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				executionContext.setXpathDataPair(spotlighttitlePath, "");
				executionContext.setCurrentElementData(spotlighttitle);
				OperationsDesktop.not_Exist(executionContext);
				
			}
			
			//Validate Spotlight Text 1
			
			if(!spotlighttext1.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(spotlighttext1Path, "");
				executionContext.setCurrentElementData(spotlighttext1);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				executionContext.setXpathDataPair(spotlighttext1Path, "");
				executionContext.setCurrentElementData(spotlighttext1);
				OperationsDesktop.not_Exist(executionContext);
				
			}
			
			//Validate Spotlight Text 1
			
			if(!spotlighttext2.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(spotlighttext2Path, "");
				executionContext.setCurrentElementData(spotlighttext2);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				executionContext.setXpathDataPair(spotlighttext2Path, "");
				executionContext.setCurrentElementData(spotlighttext2);
				OperationsDesktop.not_Exist(executionContext);
				
			}
			
			//Validate Spotlight Text 1
			if(!refilltitle.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(refilltitlePath, "");
				executionContext.setCurrentElementData(refilltitle);
				OperationsDesktop.validate_Object_Text(executionContext);
			
			}else {
				executionContext.setXpathDataPair(refilltitlePath, "");
				executionContext.setCurrentElementData(refilltitle);
				OperationsDesktop.not_Exist(executionContext);
			}
			
			
			//Validate Spotlight Text 1
			if(!refilltext.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(refilltextPath, "");
				executionContext.setCurrentElementData(refilltext);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				executionContext.setXpathDataPair(refilltextPath, "");
				executionContext.setCurrentElementData(refilltext);
				OperationsDesktop.not_Exist(executionContext);
			}
			
			
			//Validate Spotlight Text 1
			if(!autorefilltext.equalsIgnoreCase("")) {
				
				executionContext.setXpathDataPair(autorefilltextPath, "");
				executionContext.setCurrentElementData(autorefilltext);
				OperationsDesktop.validate_Object_Text(executionContext);
				
			}else {
				
				executionContext.setXpathDataPair(autorefilltextPath, "");
				executionContext.setCurrentElementData(autorefilltext);
				OperationsDesktop.not_Exist(executionContext);
			}


		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);


	}
	
	@And("^User Navigates to All Prescription Page$")
	public void User_Navigates_to_All_Prescription_Page () {
		
		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Static Wait to wait for few mins before checking on the prescription schedule
						// link
						executionContext.setCurrentElementData("6000");
						OperationsDesktop.wait(executionContext);

						Actions act = new Actions (executionContext.getDriver());
						String myPrescriptions = ExecutionContext.getObjectLocator(
								DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage",
								"wElt_MyPrescriptions", Browser);
						executionContext.setXpathDataPair(myPrescriptions, "");
						OperationsDesktop.mouse_Hover(executionContext);

						// Click All prescriptions link
						String allPrescriptionLink = ExecutionContext.getObjectLocator(
								DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
								"wLnk_AllPrescriptions", Browser);
						executionContext.setXpathDataPair(allPrescriptionLink, "");
						OperationsDesktop.click(executionContext);

						executionContext.setCurrentElementData("6000");
						OperationsDesktop.wait(executionContext);			

			
		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		
	}
	
	@When("^User switch to \"([^\"]*)\" tab in All Rx Page$")
	public void user_switch_to_Caregivee_tab_in_All_Rx_page (String caregivee) {
		
		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get required data from data base
			caregivee = executionContext.getExecutionData("caregivee", caregivee);
			String careGiveeListPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "AllPrescriptions_Page",
					"wLnk_CareGivee", Browser);
			
			//careGiveeListPath = careGiveeListPath.replace("REPLACECAREGIVEE", caregivee);

			// Get the caregivee elements in a list
			List<WebElement> eCareGiveeList = executionContext.getDriver().findElements(By.xpath(careGiveeListPath));


			if(caregivee==null) {

				Log.writeToLogFile(
						"caregivee info is not provided in the feature file or data table");
				String expectedResult = "Care Givee Name is not given in the Data table, hence not searching for caregivee tab";
				String actualResult = "Care Givee Name is not given in the Data table, hence not searching for caregivee tab";
				boolean status = true;
				ReportUtility.reportStepStatus(executionContext, expectedResult, actualResult, status);
			}
			else {
				// Check if the size of the list is greater than Zero
				if (eCareGiveeList.size() > 0) {

					boolean bCareGiveeFound = false;
					// Looping through the care givee list to switch to a cage givee mentioned in
					// the data file or in Feature file
					for (WebElement el : eCareGiveeList) {

						if (el.getText().equalsIgnoreCase(caregivee) || el.getText().contains(caregivee)) {

							el.click();
							bCareGiveeFound = true;
							// Static Wait
							executionContext.setCurrentElementData("10000");
							OperationsDesktop.wait(executionContext);
/*
							String careGiveeNamePath = ExecutionContext.getObjectLocator(
									DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
									"PrescriptionSchedule_Page", "wElt_PrescriptionSchedule_CareGivee", Browser);
							careGiveeNamePath = careGiveeNamePath.replace("REPLACE###", caregivee);
							executionContext.setXpathDataPair(careGiveeNamePath, "");
							OperationsDesktop.exist(executionContext);*/
							break;

						}

					} // End Of For

					if (!bCareGiveeFound) {

						Log.writeToLogFile(
								"No Caregivee or GareGiver with given name as " + caregivee + " is found in the page");
						// Pasting Screen shot in the report for user verification
						if (PropertyFileLoader.getInstance().getSCREENSHOTS_EVERYWHERE().equalsIgnoreCase("YES")) {
							byte[] screenshot = ((TakesScreenshot) executionContext.getDriver())
									.getScreenshotAs(OutputType.BYTES);
							executionContext.getScenario().embed(screenshot, "image/png");
						}
					}

				} else {

					Log.writeToLogFile(
							"No Caregivee or GareGiver tab is found in the page, may be page is not loaded properly");
					// Pasting Screen shot in the report for user verification
					if (PropertyFileLoader.getInstance().getSCREENSHOTS_EVERYWHERE().equalsIgnoreCase("YES")) {
						byte[] screenshot = ((TakesScreenshot) executionContext.getDriver())
								.getScreenshotAs(OutputType.BYTES);
						executionContext.getScenario().embed(screenshot, "image/png");
					}
				} // End Of If

			}

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

		
	}
	
	
	@Then("^User is not able to see the prescription Schedule link$")
	public void user_is_not_able_to_see_prescription_schedule_link() {
		
		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Static Wait
				executionContext.setCurrentElementData("2000");
				OperationsDesktop.wait(executionContext);

				// Verify user is on prescription schedule page or not
				String getStartedLink= ExecutionContext.getObjectLocator(
						DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "AllPrescriptions_Page",
						"wLnk_GetStarted", Browser);
						executionContext.setXpathDataPair(getStartedLink, "");
						OperationsDesktop.not_Exist(executionContext);
			
		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	
	

@Then("^user is able to see updated legal disclaimer as displayed in \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"")
	public void user_is_able_to_see_updated_legal_disclaimer_as_displayed_in (String section1 , String section2 , String section3 ) {


		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file			
			section1 = executionContext.getExecutionData("section1", section1);
			section2= executionContext.getExecutionData("section2", section2);
			section3= executionContext.getExecutionData("section3", section3);
			executionContext.setCurrentElementData("10000");
			OperationsDesktop.wait(executionContext);	
			
			
			// Retrieve all the xpath needed for validation
			String section1path = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section1", Browser);
			System.out.println(section1path);
			String section2path = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section2", Browser);
			System.out.println(section2path);
			String section3path = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section3", Browser);
			System.out.println(section3path);
			
			Actions act = new Actions (executionContext.getDriver());
			executionContext.setXpathDataPair(section1path, ""); 
			OperationsDesktop.scroll_To_Object (executionContext);
			
			//Validate Legal Disclaimer 1
			executionContext.setXpathDataPair(section1path, "");
			executionContext.setCurrentElementData(section1);
			OperationsDesktop.validate_Object_Text(executionContext);
			executionContext.setCurrentElementData("2000");
			OperationsDesktop.wait(executionContext);
			
			//Validate Legal Disclaimer 2
			executionContext.setXpathDataPair(section2path, "");
			executionContext.setCurrentElementData(section2);
			OperationsDesktop.validate_Object_Text(executionContext);
			
			
			//Validate Legal Disclaimer 3
			executionContext.setXpathDataPair(section3path, "");
			executionContext.setCurrentElementData(section3);
			OperationsDesktop.validate_Object_Text(executionContext);
			
			

		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);


	}
	
	@Then("^user view blank legal disclaimer as displayed in \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"")
	public void user_view_blank_legal_disclaimer_as_displayed_in (String blanksection1 , String blanksection2 , String blanksection3 ) {


		reportUtility.performInitialSetupForStep(executionContext);

		try {

			// Get Data from DB or from Feature file			
			blanksection1 = executionContext.getExecutionData("section1", blanksection1);
			blanksection2= executionContext.getExecutionData("section2", blanksection2);
			blanksection3= executionContext.getExecutionData("section3", blanksection3);
				
			
			// Retrieve all the xpath needed for validation
			String section1blankpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section1", Browser);
			
			String section2blankpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section2", Browser);
			
			String section3blankpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSchedule_Page",
					"wElt_section3", Browser);
			
						
			//Validate Legal Disclaimer 1
			executionContext.setXpathDataPair(section1blankpath, "");
			executionContext.setCurrentElementData(blanksection1);
			OperationsDesktop.not_Exist(executionContext);
			
			
			//Validate Legal Disclaimer 2
			executionContext.setXpathDataPair(section2blankpath, "");
			executionContext.setCurrentElementData(blanksection2);
			OperationsDesktop.not_Exist(executionContext);
			
			
			//Validate Legal Disclaimer 3
			executionContext.setXpathDataPair(section3blankpath, "");
			executionContext.setCurrentElementData(blanksection3);
			OperationsDesktop.not_Exist(executionContext);
			
			

		}catch (Exception e) {

			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);


		
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
