package test.java.stepdefs.com.cvshealth.digital.bab.Shop;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class SeeAllReviews extends AbstractStepDefinition {

	@Given("^search for a product \"([^\"]*)\" from CVS home page$")
	public void search_for_a_product_from_CVS_home_page(String searchkey) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Get required data from data base
					searchkey=executionContext.getExecutionData("searchkey", searchkey);
					
					//Input search key
					String ObjSearchXpath = ExecutionContext.getObjectLocator("CVS_HomePage", "wEdt_SearchBox", Browser);
					executionContext.setXpathDataPair(ObjSearchXpath, searchkey);
					OperationsDesktop.input(executionContext);
					
					//Click on search button
					String BtnSearchbox = ExecutionContext.getObjectLocator("CVS_HomePage", "wBtn_Search", Browser);
					executionContext.setXpathDataPair(BtnSearchbox, "");
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			  
	}

	@Then("^click on See all reviews link to naviagte to See All Reviews Page$")
	public void click_on_See_all_reviews_link_to_naviagte_to_See_All_Reviews_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Click on the See all reviews link
					String SeeAllReviews = ExecutionContext.getObjectLocator("CVS_PDP_BB", "wLnk_SeeAllReviews", Browser);
					executionContext.setXpathDataPair(SeeAllReviews, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
			  
	}

    @Then("^validate the Page contents on the See All Reviews Page$")
	public void validate_the_Page_contents_on_the_See_All_Reviews_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate web elements
					String CVSLogo = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_CVSLogo", Browser);
					executionContext.setXpathDataPair(CVSLogo, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					//OperationsDesktop.exist(executionContext);
					String ShopAllCategory = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_ShopAllCat", Browser);
					executionContext.setXpathDataPair(ShopAllCategory, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String HomeBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Home_Breadcrumb", Browser);
					executionContext.setXpathDataPair(HomeBreadcrumb, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					//OperationsDesktop.exist(executionContext);
					String ShopBradcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Shop_Breadcrumb", Browser);
					executionContext.setXpathDataPair(ShopBradcrumb, "");
					OperationsDesktop.wait_For_Object(executionContext);
				//OperationsDesktop.exist(executionContext);
					String CategoryBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Category_Breadcrumb", Browser);
					executionContext.setXpathDataPair(CategoryBreadcrumb, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String SubCategoryBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_SubCategory_Breadcrumb", Browser);
					executionContext.setXpathDataPair(SubCategoryBreadcrumb, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String ProductBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Product_Breadcrumb", Browser);
					executionContext.setXpathDataPair(ProductBreadcrumb, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String StarReview = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_StarReview", Browser);
					executionContext.setXpathDataPair(StarReview, "");
					OperationsDesktop.wait_For_Object(executionContext);
					//OperationsDesktop.exist(executionContext);
					String RatingSnapshot = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_RatingSnapshot", Browser);
					executionContext.setXpathDataPair(RatingSnapshot, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String RatingSnapshotDetails = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_RatingSnapshotDetails", Browser);
					executionContext.setXpathDataPair(RatingSnapshotDetails, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String AverageCustomerRating = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_AverageCustomerRating", Browser);
					executionContext.setXpathDataPair(AverageCustomerRating, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String SortBy = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_SortBy", Browser);
					executionContext.setXpathDataPair(SortBy, "");
					OperationsDesktop.scroll_To_Object(executionContext);
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String FilterHamburger = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_FilterHamburger", Browser);
					executionContext.setXpathDataPair(FilterHamburger, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					String Reviwes1to30 = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_Reviwes1to30", Browser);
					executionContext.setXpathDataPair(Reviwes1to30, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
    
    @Then("^Users select one of the stars from the Snapshot to filter the reviews list to view only those reviews for the star rating$")
    public void users_select_one_of_the_stars_from_the_Snapshot_to_filter_the_reviews_list_to_view_only_those_reviews_for_the_star_rating() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Apply 5 Star filter from Rating Snapshot
					String Reviwe_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Reviwe_5Star_Fliter", Browser);
					executionContext.setXpathDataPair(Reviwe_5Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Active_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_5Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_5Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Validate the reviews list filter is not additive$")
    public void validate_the_reviews_list_filter_is_not_additive() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Apply 4 Star filter from Rating Snapshot on already applied 5star filter
					String Reviwe_4Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Reviwe_4Star_Fliter", Browser);
					executionContext.setXpathDataPair(Reviwe_4Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Active_4Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_4Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_4Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					//Verify previously applied 5 star filter removed from Active filter list
					String Active_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_5Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_5Star_Fliter, "");
					OperationsDesktop.not_Exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Users Hover over the average rating to see the rating snapshot$")
    public void users_Hover_over_the_average_rating_to_see_the_rating_snapshot() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Open the Header Rating Details
					String HeaderRating = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_HeaderRating", Browser);
					executionContext.setXpathDataPair(HeaderRating, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
					//OperationsDesktop.click(executionContext);
					//OperationsDesktop.wait_Page_Load(executionContext);
					
					//Header Review filter will displayed
					
					String HeaderRatingBody = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wObj_HeaderReviwe_Fliter", Browser);
					executionContext.setXpathDataPair(HeaderRatingBody, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Validate the Rating Snapshot filter is additive$")
    public void validate_the_Rating_Snapshot_filter_is_additive() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Open the Header Rating Details
					String HeaderRating = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_HeaderRating", Browser);
					executionContext.setXpathDataPair(HeaderRating, "");
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
					
					//Apply 4 Star filter from Header Rating Snapshot on already applied 5 star filter
					String HeaderReviwe_4Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_HeaderReviwe_4Star_Fliter", Browser);
					executionContext.setXpathDataPair(HeaderReviwe_4Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Active_4Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_4Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_4Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					//Verify previously applied 5 star filter also their in Active filter list
					String Active_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_5Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_5Star_Fliter, "");
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    
    @Then("^Users select one of the stars from Header to filter the reviews list to view only those reviews for the star rating$")
    public void users_select_one_of_the_stars_from_Header_to_filter_the_reviews_list_to_view_only_those_reviews_for_the_star_rating() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					/*//Open the Header Rating Details
					String HeaderRating = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_HeaderRating", Browser);
					executionContext.setXpathDataPair(HeaderRating, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
					//OperationsDesktop.click(executionContext);
					//OperationsDesktop.wait_Page_Load(executionContext);*/
									
					//Apply 5 Star filter from Rating Header
					String Header_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_HeaderReviwe_5Star_Fliter", Browser);
					executionContext.setXpathDataPair(Header_5Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Active_5Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_5Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_5Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    
    @Then("^User select the hamburger next to the review sort options$")
    public void user_select_the_hamburger_next_to_the_review_sort_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Click on the hamburger next to the review sort options
					String HamburgerFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_HamburgerFilter", Browser);
					executionContext.setXpathDataPair(HamburgerFilter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String HamburgerActiveFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_HamburgerActiveFilter", Browser);
					executionContext.setXpathDataPair(HamburgerActiveFilter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Validate that after clicking on hamburger menu Review filters get exposed$")
    public void validate_that_after_clicking_on_hamburger_menu_Review_filters_get_exposed() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate the Rating filter get exposed
					String RatingFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_RatingFilter", Browser);
					executionContext.setXpathDataPair(RatingFilter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
						
					String AgeFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_AgeFilter", Browser);
					executionContext.setXpathDataPair(AgeFilter, "");
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String GenderFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_GenderFilter", Browser);
					executionContext.setXpathDataPair(GenderFilter, "");
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String EC_MemberFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_EC_MemberFilter", Browser);
					executionContext.setXpathDataPair(EC_MemberFilter, "");
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Club_MemberFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Club_MemberFilter", Browser);
					executionContext.setXpathDataPair(Club_MemberFilter, "");
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String PharmacyFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_CVSFilter", Browser);
					executionContext.setXpathDataPair(PharmacyFilter, "");
					//OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Apply any filter from the exposed list$")
    public void Apply_any_filter_from_the_exposed_list() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Apply Rating filter
					String RatingFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_RatingFilter", Browser);
					executionContext.setXpathDataPair(RatingFilter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
						
					String Rating_1StarFilter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_RatingFilter_1star", Browser);
					executionContext.setXpathDataPair(Rating_1StarFilter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					
					//Validate active filter
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Active_1Star_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Applied_1Star_ReviewFilter", Browser);
					executionContext.setXpathDataPair(Active_1Star_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    
    @Then("^Click on the Clear All button to clear the all applied filter$")
    public void click_on_the_Clear_All_button_to_clear_the_all_applied_filter() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate active filter
					String ActiveFilters = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFilters, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					//Click on Clear All filter
					
					String ClearAll_Fliter = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_ClearAll_ActiveFilter", Browser);
					executionContext.setXpathDataPair(ClearAll_Fliter, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					
					//Validate active filter gone
					String ActiveFiltersRemoved = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_ActiveFilters", Browser);
					executionContext.setXpathDataPair(ActiveFiltersRemoved, "");
					OperationsDesktop.not_Exist(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    
    @Then("^Validate that default sort should be Most Recent$")
    public void validate_that_default_sort_should_be_Most_Recent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					//Validate default sort should be Most Recent
					String MostRecentSortDefault = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostRecentSortDefault", Browser);
					executionContext.setXpathDataPair(MostRecentSortDefault, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Hover over this section to view all sort options$")
    public void hover_over_this_section_to_view_all_sort_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Hover over sort options
					String Sort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Sort", Browser);
					executionContext.setXpathDataPair(Sort, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
					
					//Validate the all sort option
				
					String MostRelevantSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostRelevantSort", Browser);
					executionContext.setXpathDataPair(MostRelevantSort, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String MostHelpfulSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostHelpfulSort", Browser);
					executionContext.setXpathDataPair(MostHelpfulSort, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String HighesttoLowestRatingSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_HighesttoLowestRatingSort", Browser);
					executionContext.setXpathDataPair(HighesttoLowestRatingSort, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String LowesttoHighestRatingSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_LowesttoHighestRatingSort", Browser);
					executionContext.setXpathDataPair(LowesttoHighestRatingSort, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String MostRecentSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostRecentSort", Browser);
					executionContext.setXpathDataPair(MostRecentSort, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Click on any sort from the sort options$")
    public void click_on_any_sort_from_the_sort_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Select the Most Helpful Sort
					String MostHelpfulSort = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostHelpfulSort", Browser);
					executionContext.setXpathDataPair(MostHelpfulSort, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }

    @Then("^Validate that now selected sort should display under sort option$")
    public void validate_that_now_selected_sort_should_display_under_sort_option() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate the Most Helpful Sort selected
					String MostHelpfulSortSet = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_MostHelpfulSortSet", Browser);
					executionContext.setXpathDataPair(MostHelpfulSortSet, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    

	@Then("^Validate that user see one to thirty review only on first time of total reviews$")
	public void validate_that_user_see_one_to_thirty_review_only_on_first_time_of_total_reviews() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate user see one to thirty review only on first time of total reviews
					String OnetoThirtyReviews = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_1to30_Reviews", Browser);
					executionContext.setXpathDataPair(OnetoThirtyReviews, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^User hover over  reviewer name to view reviewer details$")
	public void user_hover_over_reviewer_name_to_view_reviewer_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Mouse hover on the first user
					String FirstReviewer = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_FirstUser", Browser);
					executionContext.setXpathDataPair(FirstReviewer, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.mouse_Hover(executionContext);
					
					//Validate the user profile of 1st reviewer
					String UserName = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserName", Browser);
					executionContext.setXpathDataPair(UserName, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					//OperationsDesktop.exist(executionContext);
					
					String UserLocation = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserLocation", Browser);
					executionContext.setXpathDataPair(UserLocation, "");
					OperationsDesktop.exist(executionContext);
					
					String UserAge = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserAge", Browser);
					executionContext.setXpathDataPair(UserAge, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserGender = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserGender", Browser);
					executionContext.setXpathDataPair(UserGender, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserEC = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserEC", Browser);
					executionContext.setXpathDataPair(UserEC, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserClub = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserClub", Browser);
					executionContext.setXpathDataPair(UserClub, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserPharmacy = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_UserPharmacy", Browser);
					executionContext.setXpathDataPair(UserPharmacy, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String SeeMyProfile = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_SeeMyProfile", Browser);
					executionContext.setXpathDataPair(SeeMyProfile, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserReview = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wEtn_UserReview", Browser);
					executionContext.setXpathDataPair(UserReview, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String UserVotes = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wEtn_UserVotes", Browser);
					executionContext.setXpathDataPair(UserVotes, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^Open user detail profile and close it$")
    public void Open_user_detail_profile_and_close_it() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					// Open user full profile
					
					String SeeMyProfileClick = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_SeeMyProfile", Browser);
					executionContext.setXpathDataPair(SeeMyProfileClick, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					String Profile_UserName = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_Profile_UserName", Browser);
					executionContext.setXpathDataPair(Profile_UserName, "");
					OperationsDesktop.wait_Page_Load(executionContext);
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Profile_Reviews = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_Profile_Reviews", Browser);
					executionContext.setXpathDataPair(Profile_Reviews, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					String Profile_Reviews_Dtls = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_Profile_Reviews", Browser);
					executionContext.setXpathDataPair(Profile_Reviews_Dtls, "");
					//OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.exist(executionContext);
					
					//Close profile details
					String Cancel_Button = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_Cancel", Browser);
					executionContext.setXpathDataPair(Cancel_Button, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.click(executionContext);
					
					String Profile_UserName_False = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wElt_Profile_UserName", Browser);
					executionContext.setXpathDataPair(Profile_UserName_False, "");
					OperationsDesktop.not_Exist(executionContext);
					
					String SeeMyProfileFlase = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_SeeMyProfile", Browser);
					executionContext.setXpathDataPair(SeeMyProfileFlase, "");
					OperationsDesktop.not_Exist(executionContext);
					
					
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
    }
    
	
	@Then("^Click on Load more button for product with more than thirty reviews$")
	public void click_on_Load_more_button_for_product_with_more_than_thirty_reviews() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate user click on the Load More button
					String LoadMore = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wBtn_LoadMore", Browser);
					executionContext.setXpathDataPair(LoadMore, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.click(executionContext);
					OperationsDesktop.wait_Page_Load(executionContext);
					
					//Validate user see 1 to 60 reviews after load more click
					
					String OnetoSixty = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_1to60_Reviews", Browser);
					executionContext.setXpathDataPair(OnetoSixty, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^Validate that now user see one to sixty reviews of total reviews$")
	public void validate_that_now_user_see_one_to_sixty_reviews_of_total_reviews() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
					System.out.println(System.getProperties());
					
					
					//Validate user see 1 to 60 reviews after load more click
					
					String OnetoSixty = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wTxt_1to60_Reviews", Browser);
					executionContext.setXpathDataPair(OnetoSixty, "");
					OperationsDesktop.wait_For_Object(executionContext);
					OperationsDesktop.scroll_To_Object(executionContext);
					OperationsDesktop.exist(executionContext);
				}
				catch (Exception e) {
					ExceptionHandler.handleException(e);
					reportUtility.setStatusOfOperationForStep(executionContext, false);
				}
				reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	 @Then("^validate the See All Reviews Page$")
		public void validate_the_See_All_Reviews_Page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
	    	reportUtility.performInitialSetupForStep(executionContext);
			try {
				
						System.out.println(System.getProperties());
						
						
						//Validate web elements
						String CVSLogo = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_CVSLogo", Browser);
						executionContext.setXpathDataPair(CVSLogo, "");
						OperationsDesktop.wait_Page_Load(executionContext);
						OperationsDesktop.wait_For_Object(executionContext);
				
						String ShopAllCategory = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_ShopAllCat", Browser);
						executionContext.setXpathDataPair(ShopAllCategory, "");
						OperationsDesktop.wait_Page_Load(executionContext);
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
						String HomeBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Home_Breadcrumb", Browser);
						executionContext.setXpathDataPair(HomeBreadcrumb, "");
						OperationsDesktop.wait_Page_Load(executionContext);
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
						String ShopBradcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Shop_Breadcrumb", Browser);
						executionContext.setXpathDataPair(ShopBradcrumb, "");
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
						String CategoryBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Category_Breadcrumb", Browser);
						executionContext.setXpathDataPair(CategoryBreadcrumb, "");
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
						String SubCategoryBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_SubCategory_Breadcrumb", Browser);
						executionContext.setXpathDataPair(SubCategoryBreadcrumb, "");
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
						String ProductBreadcrumb = ExecutionContext.getObjectLocator("CVS_SeeAllReviews_BB", "wLnk_Product_Breadcrumb", Browser);
						executionContext.setXpathDataPair(ProductBreadcrumb, "");
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.exist(executionContext);
							
					}
					catch (Exception e) {
						ExceptionHandler.handleException(e);
						reportUtility.setStatusOfOperationForStep(executionContext, false);
					}
					reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
		}
	 
		@Then("^click on review count link$")
		public void click_on_review_count_link() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			reportUtility.performInitialSetupForStep(executionContext);
			try {
				
						System.out.println(System.getProperties());
						
						
						//Click on the See all reviews link
						String SeeAllReviews = ExecutionContext.getObjectLocator("CVS_PLP_BB", "wLnk_ReviewCnt_PLP", Browser);
						executionContext.setXpathDataPair(SeeAllReviews, "");
						OperationsDesktop.wait_For_Object(executionContext);
						OperationsDesktop.click(executionContext);
						OperationsDesktop.wait_Page_Load(executionContext);
						
					}
					catch (Exception e) {
						ExceptionHandler.handleException(e);
						reportUtility.setStatusOfOperationForStep(executionContext, false);
					}
					reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
				  
		}
    
}
