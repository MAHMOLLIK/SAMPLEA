package test.java.stepdefs.com.cvshealth.digital.rxm.icestabilitycvs;

import org.junit.Assert;
import org.openqa.selenium.By;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;
import test.java.stepdefs.com.cvshealth.digital.library.PropertyFileLoader;

public class IceCvsLogin extends AbstractStepDefinition {
	
	@Given("^user on CVS ICE Pharmacy home page$")
	public void User_on_CVS_ICE_home_page() {
		// Write code here that turns the phrase above into concrete actions
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			System.out.println(System.getProperties());
			//Get required data from data base
					
			/*for each method call, user should set xpath-data pair and then call method
			pass empty string respectively when xpath/data is not required to call the method*/
			
			//navigateUrl - set url to execution context
			//set current execution data
			executionContext.setXpathDataPair("", PropertyFileLoader.getInstance().getURL());
			
			//in this example only URL is expected
			//execute generic method inside the assert statement to terminate in case of failure
			Assert.assertTrue("URL "+PropertyFileLoader.getInstance().getURL()+ " navigated successfully", OperationsDesktop.navigateURL(executionContext));
			
			/*//read xpath for email address edit box object
			//String userNameXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_EmailAddress",Browser);			
			String userNameXPath=ExecutionContext.getObjectLocator("ICE_PharmacyPage","wEdt_EmailAddress",Browser);
			//set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(userNameXPath, "");			
			//set current execution context and advance to the next working element
			OperationsDesktop.wait_For_Object(executionContext);
			
			executionContext.setXpathDataPair(userNameXPath, userName);
			//set current xpath and data for input method
			OperationsDesktop.input(executionContext);
			
			//set current xpath and current data for input function
			//String userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wEdt_Password",Browser);
			String userPasswordxPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			
			//click
			String signInButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage","wBtn_SignIn",Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);
			
			//wait_For_Object
			String signoutButtonXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage","wLnk_SignOut",Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);*/
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and(String username, String password) throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			username = executionContext.getExecutionData("username", username);
			password = executionContext.getExecutionData("password", password);

			// read xpath for email address edit box object
			// String
			// userNameXPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
			// "ICE_PharmacyPage","wEdt_EmailAddress",Browser);
			String userNameXPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_EmailAddress", Browser);
			// set current object xpath, data is not required for "wait_for_object" method
			executionContext.setXpathDataPair(userNameXPath, "");
			// set current execution context and advance to the next working element
			OperationsDesktop.wait_For_Object(executionContext);

			executionContext.setXpathDataPair(userNameXPath, username);
			// set current xpath and data for input method
			OperationsDesktop.input(executionContext);

			// set current xpath and current data for input function
			// String
			// userPasswordxPath=ExecutionContext.getObjectLocator(DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(),
			// "ICE_PharmacyPage","wEdt_Password",Browser);
			String userPasswordxPath = ExecutionContext.getObjectLocator("ICE_PharmacyPage", "wEdt_Password", Browser);
			executionContext.setXpathDataPair(userPasswordxPath, password);
			OperationsDesktop.input(executionContext);

			// click
			String signInButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_PharmacyPage", "wBtn_SignIn",
					Browser);
			executionContext.setXpathDataPair(signInButtonXPath, "");
			OperationsDesktop.click(executionContext);
			//wait for Page to load
			OperationsDesktop.wait_Page_Load(executionContext);

			// wait_For_Object
			String signoutButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "ICE_Pharmacy_LoginPage",
					"wLnk_SignOut", Browser);
			executionContext.setXpathDataPair(signoutButtonXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	@Then("^user navigates to Mydashboard Page$")
	public void user_navigates_to_Mydashboard_Page() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String dashboardXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wTxt_Pharmacy", Browser);
			executionContext.setXpathDataPair(dashboardXPath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
/****************************************************************************************************************
 * 
 * Scenario 2 View All Prescriptions
 * **************************************************************************************************************
 */
	@Then("^user navigates to AllPrescriptions under MyPrescriptions$")
	public void user_navigates_to_AllPrescriptions_under_MyPrescriptions() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String myPrescriptionXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wElt_MyPrescriptions", Browser);
			executionContext.setXpathDataPair(myPrescriptionXPath, "");
			OperationsDesktop.mouse_Hover(executionContext);
			
			String allPrescriptionXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wLnk_AllPrecrptions", Browser);
			executionContext.setXpathDataPair(allPrescriptionXPath, "");
			OperationsDesktop.click(executionContext);
			//wait for page load
			OperationsDesktop.wait_Page_Load(executionContext);
			
			// wait_For_Object
						String VeiwAllPrescriptionsXPath = ExecutionContext.getObjectLocator(
								DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_ICE_ViewAllPrescriptions",
								"wTxt_AllPrescriptions", Browser);
						executionContext.setXpathDataPair(VeiwAllPrescriptionsXPath, "");
						OperationsDesktop.wait_For_Object(executionContext);
						
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	@Then("^user lands in View All Prescriptions Page$")
	public void user_lands_in_View_All_Prescriptions_Page() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			String VeiwAllPrescriptionsXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_ICE_ViewAllPrescriptions",
					"wTxt_AllPrescriptions", Browser);
			executionContext.setXpathDataPair(VeiwAllPrescriptionsXPath, "");
			OperationsDesktop.wait_Page_Load(executionContext);
			OperationsDesktop.wait_For_Object(executionContext);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}

		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	/****************************************************************************************************************
	 * 
	 * Scenario 3 count of prescriptions on Dashboard widgets
	 * **************************************************************************************************************
	 */
			
	@Then("^user can see the count of prescriptions on dashboard$")
	public void user_can_see_the_count_of_prescriptions_on_dashboard() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String PrescriptionsCountXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wTxt_Prescriptions", Browser);
			executionContext.setXpathDataPair(PrescriptionsCountXPath, "");
			OperationsDesktop.exist(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
	
	/****************************************************************************************************************
	 * 
	 * Scenario 4 Refill All Buttons Top and Bottom on Dashboard widgets
	 * **************************************************************************************************************
	 */
	
	@Then("^user can see RefillAll Top Button on dashboard$")
	public void user_can_see_RefillAll_Top_Button_on_dashboard() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String RefillAllTopButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wBtn_RefillAll_Top", Browser);
			executionContext.setXpathDataPair(RefillAllTopButtonXPath, "");
			OperationsDesktop.exist(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}
	
	@Then("^user can see RefillAll Bottom Button on dashboard$")
	public void user_can_see_RefillAll_Bottom_Button_on_dashboard() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			String RefillAllBottomButtonXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "CVS_Dashboard_Page",
					"wBtn_RefillAll_Bottom", Browser);
			executionContext.setXpathDataPair(RefillAllBottomButtonXPath, "");
			OperationsDesktop.exist(executionContext);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

}


	

