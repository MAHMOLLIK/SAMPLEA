package test.java.stepdefs.com.cvshealth.digital.cat.savingtools;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.DBCacheSingleton;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class CaregiverCaregiveeSavings extends AbstractStepDefinition {

	@Then("^user should see the caregivee section intro \"([^\"]*)\" and caregivee list \"([^\"]*)\"$")
	public void user_should_see_the_caregivee_section_intro_and_caregivee_list(String message, String caregivee_list) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {

			// check for promo heading
			String messageXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageXpath = messageXpath.replaceAll("dynamic_prescSavingsNames", message.trim());
			executionContext.setXpathDataPair(updatedmessageXpath, "");
			OperationsDesktop.exist(executionContext);

			// split caregivees into an array
			String[] caregivees = caregivee_list.split(",");
			String caregiveeXPath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			// check for each caregivee
			for (String caregivee : caregivees) {
				String updatedcaregiveeXPath = caregiveeXPath.replaceAll("dynamic_prescSavingsNames", caregivee.trim());
				executionContext.setXpathDataPair(updatedcaregiveeXPath, "");
				OperationsDesktop.exist(executionContext);
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@When("^user clicks on \"([^\"]*)\" on SFT page$")
	public void user_clicks_on_on_SFT_page(String caregiveeName) {

		reportUtility.performInitialSetupForStep(executionContext);
		try {

			// click on caregivee
			String caregiveeXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedcaregiveeXpath = caregiveeXpath.replaceAll("dynamic_prescSavingsNames", caregiveeName.trim());
			executionContext.setXpathDataPair(updatedcaregiveeXpath, "");
			OperationsDesktop.click(executionContext);
			
			//wait for page load
			String messageXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "MyPrescriptionsFinderPage",
					"wTxt_prescriptionSavingsNames", Browser);
			String updatedmessageXpath = messageXpath.replaceAll("dynamic_prescSavingsNames",
					"How does CVS Pharmacy find me savings?");
			executionContext.setXpathDataPair(updatedmessageXpath, "");
			OperationsDesktop.wait_For_Object(executionContext);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);
	}

	@Then("^the savings total \\$ amount changes to include caregivee saving$")
	public void the_savings_total_$_amount_changes_to_include_caregivee_saving() {
	
	
	}
	
	@Then ("user should see the top line \"([^\"]*)\" updated")
	public void user_should_see_the_top_line_message_updated(String message) {
		reportUtility.performInitialSetupForStep(executionContext);
		try {
			
			// Get required data from data base
			message = executionContext.getExecutionData("message", message);
			
			
			String caregiveeSavingsMessageXpath = ExecutionContext.getObjectLocator(
					DBCacheSingleton.getInstance().getHashMapObjectRepositoryData(), "PrescriptionSavings_Page",
					"wElt_CaregiveeSavingsMessage", Browser);
			//String updatedcaregiveeXpath = caregiveeXpath.replaceAll("dynamic_prescSavingsNames", caregiveeName.trim());
			executionContext.setXpathDataPair(caregiveeSavingsMessageXpath, message);
			OperationsDesktop.validate_Object_Text(executionContext);
			
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);

		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}
}
