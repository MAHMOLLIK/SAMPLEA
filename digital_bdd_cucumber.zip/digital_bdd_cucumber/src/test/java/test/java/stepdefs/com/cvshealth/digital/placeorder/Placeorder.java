package test.java.stepdefs.com.cvshealth.digital.placeorder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.java.stepdefs.com.cvshealth.digital.library.AbstractStepDefinition;
import test.java.stepdefs.com.cvshealth.digital.library.ExceptionHandler;
import test.java.stepdefs.com.cvshealth.digital.library.ExecutionContext;
import test.java.stepdefs.com.cvshealth.digital.library.OperationsDesktop;

public class Placeorder extends AbstractStepDefinition{

	@Given("^Search the given item in search field$")
	public void search_the_given_item_in_search_field() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);		
		String searchXpath = ExecutionContext.getObjectLocator("Demo_Script", "wBtn_Search", "Browser");		
		executionContext.setXpathDataPair(searchXpath, "Medicine");
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.input(executionContext);	

	}

	@Given("^Select the first resulting item$")
	public void select_the_first_resulting_item() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);
		String searchIcon = ExecutionContext.getObjectLocator("Demo_Script", "wBtn_SearchIcon", "Browser");
		executionContext.setXpathDataPair(searchIcon, "");
		OperationsDesktop.wait_For_Object(executionContext);
		OperationsDesktop.click(executionContext);

	}

	@Given("^click on checkout item button$")
	public void click_on_checkout_item_button() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);

		try {
			String addToBasket = ExecutionContext.getObjectLocator("products_page", "wProductItem", "Browser");
			executionContext.setXpathDataPair(addToBasket, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);


			String clickCheckOut = ExecutionContext.getObjectLocator("products_page", "wCheckOutBtn", "Browser");
			executionContext.setXpathDataPair(clickCheckOut, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);


			String clickCheckOutnOW = ExecutionContext.getObjectLocator("products_page", "wcheckOutNow", "Browser");
			executionContext.setXpathDataPair(clickCheckOutnOW, "");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.click(executionContext);
		}
		catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^Entering shipping details$")
	public void entering_shipping_details() throws Throwable {
		reportUtility.performInitialSetupForStep(executionContext);		

		try {
			String fullName = ExecutionContext.getObjectLocator("checkoutPage", "inserFullName", "Browser");		
			executionContext.setXpathDataPair(fullName, "Mohammed Molik");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);

			String streeAddress = ExecutionContext.getObjectLocator("checkoutPage", "inserStreetAddress", "Browser");		
			executionContext.setXpathDataPair(streeAddress, "1 CVS Dr");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String city = ExecutionContext.getObjectLocator("checkoutPage", "inserCity", "Browser");		
			executionContext.setXpathDataPair(city, "Woonsocket");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			String state = ExecutionContext.getObjectLocator("checkoutPage", "inserCity", "Browser");		
			executionContext.setXpathDataPair(state, "Woonsocket");
			OperationsDesktop.wait_For_Object(executionContext);
			OperationsDesktop.input(executionContext);
			
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
			reportUtility.setStatusOfOperationForStep(executionContext, false);
		}
		reportUtility.finalStatusSetupToExecuteForEveryStep(executionContext);

	}

	@When("^Enter Payment details$")
	public void enter_Payment_details() throws Throwable {


	}

	@When("^click the place order$")
	public void click_the_place_order() throws Throwable {


	}

	@Then("^get the order number$")
	public void get_the_order_number() throws Throwable {


	}

	@Then("^Verify the Order Details\\.$")
	public void verify_the_Order_Details() throws Throwable {


	}

}
